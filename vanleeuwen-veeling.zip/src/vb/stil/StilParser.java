// $ANTLR 3.5.2 Stil.g 2014-07-09 16:07:34

    package vb.stil;
    import  vb.stil.tree.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;


@SuppressWarnings("all")
public class StilParser extends Parser {
	public static final String[] tokenNames = new String[] {
		"<invalid>", "<EOR>", "<DOWN>", "<UP>", "AND", "APOS", "BECOMES", "BOOL", 
		"CHAR", "CHARALL", "CHAR_LITERAL", "COLON", "COMMA", "COMMENT", "COMPOUND_EXPR", 
		"CONST", "DIGIT", "DIVIDE", "ELSE", "EQ", "FALSE", "GT", "GTE", "IDENTIFIER", 
		"IF", "INT", "INT_LITERAL", "LCURLY", "LETTER", "LOWER", "LPAREN", "LT", 
		"LTE", "MINUS", "MODULO", "MULTIPLY", "NEQ", "NOT", "OR", "PLUS", "PRINT", 
		"PROGRAM", "RCURLY", "READ", "RPAREN", "SEMICOLON", "TRUE", "UNARY_MINUS", 
		"UNARY_NOT", "UNARY_PLUS", "UPPER", "VAR", "WHILE", "WS"
	};
	public static final int EOF=-1;
	public static final int AND=4;
	public static final int APOS=5;
	public static final int BECOMES=6;
	public static final int BOOL=7;
	public static final int CHAR=8;
	public static final int CHARALL=9;
	public static final int CHAR_LITERAL=10;
	public static final int COLON=11;
	public static final int COMMA=12;
	public static final int COMMENT=13;
	public static final int COMPOUND_EXPR=14;
	public static final int CONST=15;
	public static final int DIGIT=16;
	public static final int DIVIDE=17;
	public static final int ELSE=18;
	public static final int EQ=19;
	public static final int FALSE=20;
	public static final int GT=21;
	public static final int GTE=22;
	public static final int IDENTIFIER=23;
	public static final int IF=24;
	public static final int INT=25;
	public static final int INT_LITERAL=26;
	public static final int LCURLY=27;
	public static final int LETTER=28;
	public static final int LOWER=29;
	public static final int LPAREN=30;
	public static final int LT=31;
	public static final int LTE=32;
	public static final int MINUS=33;
	public static final int MODULO=34;
	public static final int MULTIPLY=35;
	public static final int NEQ=36;
	public static final int NOT=37;
	public static final int OR=38;
	public static final int PLUS=39;
	public static final int PRINT=40;
	public static final int PROGRAM=41;
	public static final int RCURLY=42;
	public static final int READ=43;
	public static final int RPAREN=44;
	public static final int SEMICOLON=45;
	public static final int TRUE=46;
	public static final int UNARY_MINUS=47;
	public static final int UNARY_NOT=48;
	public static final int UNARY_PLUS=49;
	public static final int UPPER=50;
	public static final int VAR=51;
	public static final int WHILE=52;
	public static final int WS=53;

	// delegates
	public Parser[] getDelegates() {
		return new Parser[] {};
	}

	// delegators


	public StilParser(TokenStream input) {
		this(input, new RecognizerSharedState());
	}
	public StilParser(TokenStream input, RecognizerSharedState state) {
		super(input, state);
	}

	protected TreeAdaptor adaptor = new CommonTreeAdaptor();

	public void setTreeAdaptor(TreeAdaptor adaptor) {
		this.adaptor = adaptor;
	}
	public TreeAdaptor getTreeAdaptor() {
		return adaptor;
	}
	@Override public String[] getTokenNames() { return StilParser.tokenNames; }
	@Override public String getGrammarFileName() { return "Stil.g"; }


	public static class program_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "program"
	// Stil.g:67:1: program : instructions EOF -> ^( PROGRAM instructions ) ;
	public final StilParser.program_return program() throws RecognitionException {
		StilParser.program_return retval = new StilParser.program_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token EOF2=null;
		ParserRuleReturnScope instructions1 =null;

		Object EOF2_tree=null;
		RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
		RewriteRuleSubtreeStream stream_instructions=new RewriteRuleSubtreeStream(adaptor,"rule instructions");

		try {
			// Stil.g:68:5: ( instructions EOF -> ^( PROGRAM instructions ) )
			// Stil.g:68:9: instructions EOF
			{
			pushFollow(FOLLOW_instructions_in_program1081);
			instructions1=instructions();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_instructions.add(instructions1.getTree());
			EOF2=(Token)match(input,EOF,FOLLOW_EOF_in_program1083); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_EOF.add(EOF2);

			// AST REWRITE
			// elements: instructions
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (Object)adaptor.nil();
			// 69:13: -> ^( PROGRAM instructions )
			{
				// Stil.g:69:17: ^( PROGRAM instructions )
				{
				Object root_1 = (Object)adaptor.nil();
				root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(PROGRAM, "PROGRAM"), root_1);
				adaptor.addChild(root_1, stream_instructions.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "program"


	public static class instructions_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "instructions"
	// Stil.g:72:1: instructions : ( ( ( declaration | expression ) SEMICOLON !) | statement )* ;
	public final StilParser.instructions_return instructions() throws RecognitionException {
		StilParser.instructions_return retval = new StilParser.instructions_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token SEMICOLON5=null;
		ParserRuleReturnScope declaration3 =null;
		ParserRuleReturnScope expression4 =null;
		ParserRuleReturnScope statement6 =null;

		Object SEMICOLON5_tree=null;

		try {
			// Stil.g:73:5: ( ( ( ( declaration | expression ) SEMICOLON !) | statement )* )
			// Stil.g:73:7: ( ( ( declaration | expression ) SEMICOLON !) | statement )*
			{
			root_0 = (Object)adaptor.nil();


			// Stil.g:73:7: ( ( ( declaration | expression ) SEMICOLON !) | statement )*
			loop2:
			while (true) {
				int alt2=3;
				int LA2_0 = input.LA(1);
				if ( (LA2_0==CHAR_LITERAL||LA2_0==CONST||LA2_0==FALSE||LA2_0==IDENTIFIER||(LA2_0 >= INT_LITERAL && LA2_0 <= LCURLY)||LA2_0==LPAREN||LA2_0==MINUS||LA2_0==NOT||(LA2_0 >= PLUS && LA2_0 <= PRINT)||LA2_0==READ||LA2_0==TRUE||LA2_0==VAR) ) {
					alt2=1;
				}
				else if ( (LA2_0==IF||LA2_0==WHILE) ) {
					alt2=2;
				}

				switch (alt2) {
				case 1 :
					// Stil.g:73:8: ( ( declaration | expression ) SEMICOLON !)
					{
					// Stil.g:73:8: ( ( declaration | expression ) SEMICOLON !)
					// Stil.g:73:9: ( declaration | expression ) SEMICOLON !
					{
					// Stil.g:73:9: ( declaration | expression )
					int alt1=2;
					int LA1_0 = input.LA(1);
					if ( (LA1_0==CONST||LA1_0==VAR) ) {
						alt1=1;
					}
					else if ( (LA1_0==CHAR_LITERAL||LA1_0==FALSE||LA1_0==IDENTIFIER||(LA1_0 >= INT_LITERAL && LA1_0 <= LCURLY)||LA1_0==LPAREN||LA1_0==MINUS||LA1_0==NOT||(LA1_0 >= PLUS && LA1_0 <= PRINT)||LA1_0==READ||LA1_0==TRUE) ) {
						alt1=2;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 1, 0, input);
						throw nvae;
					}

					switch (alt1) {
						case 1 :
							// Stil.g:73:10: declaration
							{
							pushFollow(FOLLOW_declaration_in_instructions1124);
							declaration3=declaration();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) adaptor.addChild(root_0, declaration3.getTree());

							}
							break;
						case 2 :
							// Stil.g:73:24: expression
							{
							pushFollow(FOLLOW_expression_in_instructions1128);
							expression4=expression();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) adaptor.addChild(root_0, expression4.getTree());

							}
							break;

					}

					SEMICOLON5=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_instructions1131); if (state.failed) return retval;
					}

					}
					break;
				case 2 :
					// Stil.g:73:50: statement
					{
					pushFollow(FOLLOW_statement_in_instructions1137);
					statement6=statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, statement6.getTree());

					}
					break;

				default :
					break loop2;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "instructions"


	public static class declaration_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "declaration"
	// Stil.g:76:1: declaration : ( constant_declaration | var_declaration );
	public final StilParser.declaration_return declaration() throws RecognitionException {
		StilParser.declaration_return retval = new StilParser.declaration_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		ParserRuleReturnScope constant_declaration7 =null;
		ParserRuleReturnScope var_declaration8 =null;


		try {
			// Stil.g:77:5: ( constant_declaration | var_declaration )
			int alt3=2;
			int LA3_0 = input.LA(1);
			if ( (LA3_0==CONST) ) {
				alt3=1;
			}
			else if ( (LA3_0==VAR) ) {
				alt3=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 3, 0, input);
				throw nvae;
			}

			switch (alt3) {
				case 1 :
					// Stil.g:77:9: constant_declaration
					{
					root_0 = (Object)adaptor.nil();


					pushFollow(FOLLOW_constant_declaration_in_declaration1158);
					constant_declaration7=constant_declaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, constant_declaration7.getTree());

					}
					break;
				case 2 :
					// Stil.g:78:9: var_declaration
					{
					root_0 = (Object)adaptor.nil();


					pushFollow(FOLLOW_var_declaration_in_declaration1169);
					var_declaration8=var_declaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, var_declaration8.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "declaration"


	public static class constant_declaration_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "constant_declaration"
	// Stil.g:81:1: constant_declaration : CONST ^ type IDENTIFIER BECOMES ! expression ;
	public final StilParser.constant_declaration_return constant_declaration() throws RecognitionException {
		StilParser.constant_declaration_return retval = new StilParser.constant_declaration_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token CONST9=null;
		Token IDENTIFIER11=null;
		Token BECOMES12=null;
		ParserRuleReturnScope type10 =null;
		ParserRuleReturnScope expression13 =null;

		Object CONST9_tree=null;
		Object IDENTIFIER11_tree=null;
		Object BECOMES12_tree=null;

		try {
			// Stil.g:82:5: ( CONST ^ type IDENTIFIER BECOMES ! expression )
			// Stil.g:82:9: CONST ^ type IDENTIFIER BECOMES ! expression
			{
			root_0 = (Object)adaptor.nil();


			CONST9=(Token)match(input,CONST,FOLLOW_CONST_in_constant_declaration1188); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			CONST9_tree = new DeclNode(CONST9) ;
			root_0 = (Object)adaptor.becomeRoot(CONST9_tree, root_0);
			}

			pushFollow(FOLLOW_type_in_constant_declaration1194);
			type10=type();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, type10.getTree());

			IDENTIFIER11=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_constant_declaration1196); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			IDENTIFIER11_tree = new IdNode(IDENTIFIER11) ;
			adaptor.addChild(root_0, IDENTIFIER11_tree);
			}

			BECOMES12=(Token)match(input,BECOMES,FOLLOW_BECOMES_in_constant_declaration1201); if (state.failed) return retval;
			pushFollow(FOLLOW_expression_in_constant_declaration1204);
			expression13=expression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, expression13.getTree());

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "constant_declaration"


	public static class var_declaration_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "var_declaration"
	// Stil.g:85:1: var_declaration : VAR ^ type IDENTIFIER ;
	public final StilParser.var_declaration_return var_declaration() throws RecognitionException {
		StilParser.var_declaration_return retval = new StilParser.var_declaration_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token VAR14=null;
		Token IDENTIFIER16=null;
		ParserRuleReturnScope type15 =null;

		Object VAR14_tree=null;
		Object IDENTIFIER16_tree=null;

		try {
			// Stil.g:86:5: ( VAR ^ type IDENTIFIER )
			// Stil.g:86:9: VAR ^ type IDENTIFIER
			{
			root_0 = (Object)adaptor.nil();


			VAR14=(Token)match(input,VAR,FOLLOW_VAR_in_var_declaration1223); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			VAR14_tree = new DeclNode(VAR14) ;
			root_0 = (Object)adaptor.becomeRoot(VAR14_tree, root_0);
			}

			pushFollow(FOLLOW_type_in_var_declaration1229);
			type15=type();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, type15.getTree());

			IDENTIFIER16=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_var_declaration1231); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			IDENTIFIER16_tree = new IdNode(IDENTIFIER16) ;
			adaptor.addChild(root_0, IDENTIFIER16_tree);
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "var_declaration"


	public static class statement_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "statement"
	// Stil.g:89:1: statement : ( if_statement | while_statement ) ;
	public final StilParser.statement_return statement() throws RecognitionException {
		StilParser.statement_return retval = new StilParser.statement_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		ParserRuleReturnScope if_statement17 =null;
		ParserRuleReturnScope while_statement18 =null;


		try {
			// Stil.g:90:5: ( ( if_statement | while_statement ) )
			// Stil.g:90:9: ( if_statement | while_statement )
			{
			root_0 = (Object)adaptor.nil();


			// Stil.g:90:9: ( if_statement | while_statement )
			int alt4=2;
			int LA4_0 = input.LA(1);
			if ( (LA4_0==IF) ) {
				alt4=1;
			}
			else if ( (LA4_0==WHILE) ) {
				alt4=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 4, 0, input);
				throw nvae;
			}

			switch (alt4) {
				case 1 :
					// Stil.g:90:10: if_statement
					{
					pushFollow(FOLLOW_if_statement_in_statement1254);
					if_statement17=if_statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, if_statement17.getTree());

					}
					break;
				case 2 :
					// Stil.g:90:25: while_statement
					{
					pushFollow(FOLLOW_while_statement_in_statement1258);
					while_statement18=while_statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, while_statement18.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "statement"


	public static class if_statement_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "if_statement"
	// Stil.g:93:1: if_statement : IF ^ LPAREN ! expression RPAREN ! LCURLY ! instructions RCURLY ! ( ELSE LCURLY ! instructions RCURLY !)? ;
	public final StilParser.if_statement_return if_statement() throws RecognitionException {
		StilParser.if_statement_return retval = new StilParser.if_statement_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token IF19=null;
		Token LPAREN20=null;
		Token RPAREN22=null;
		Token LCURLY23=null;
		Token RCURLY25=null;
		Token ELSE26=null;
		Token LCURLY27=null;
		Token RCURLY29=null;
		ParserRuleReturnScope expression21 =null;
		ParserRuleReturnScope instructions24 =null;
		ParserRuleReturnScope instructions28 =null;

		Object IF19_tree=null;
		Object LPAREN20_tree=null;
		Object RPAREN22_tree=null;
		Object LCURLY23_tree=null;
		Object RCURLY25_tree=null;
		Object ELSE26_tree=null;
		Object LCURLY27_tree=null;
		Object RCURLY29_tree=null;

		try {
			// Stil.g:94:5: ( IF ^ LPAREN ! expression RPAREN ! LCURLY ! instructions RCURLY ! ( ELSE LCURLY ! instructions RCURLY !)? )
			// Stil.g:94:9: IF ^ LPAREN ! expression RPAREN ! LCURLY ! instructions RCURLY ! ( ELSE LCURLY ! instructions RCURLY !)?
			{
			root_0 = (Object)adaptor.nil();


			IF19=(Token)match(input,IF,FOLLOW_IF_in_if_statement1278); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			IF19_tree = (Object)adaptor.create(IF19);
			root_0 = (Object)adaptor.becomeRoot(IF19_tree, root_0);
			}

			LPAREN20=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_if_statement1281); if (state.failed) return retval;
			pushFollow(FOLLOW_expression_in_if_statement1284);
			expression21=expression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, expression21.getTree());

			RPAREN22=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_if_statement1286); if (state.failed) return retval;
			LCURLY23=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_if_statement1289); if (state.failed) return retval;
			pushFollow(FOLLOW_instructions_in_if_statement1292);
			instructions24=instructions();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, instructions24.getTree());

			RCURLY25=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_if_statement1294); if (state.failed) return retval;
			// Stil.g:94:69: ( ELSE LCURLY ! instructions RCURLY !)?
			int alt5=2;
			int LA5_0 = input.LA(1);
			if ( (LA5_0==ELSE) ) {
				alt5=1;
			}
			switch (alt5) {
				case 1 :
					// Stil.g:94:70: ELSE LCURLY ! instructions RCURLY !
					{
					ELSE26=(Token)match(input,ELSE,FOLLOW_ELSE_in_if_statement1298); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					ELSE26_tree = (Object)adaptor.create(ELSE26);
					adaptor.addChild(root_0, ELSE26_tree);
					}

					LCURLY27=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_if_statement1300); if (state.failed) return retval;
					pushFollow(FOLLOW_instructions_in_if_statement1303);
					instructions28=instructions();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, instructions28.getTree());

					RCURLY29=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_if_statement1305); if (state.failed) return retval;
					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "if_statement"


	public static class while_statement_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "while_statement"
	// Stil.g:97:1: while_statement : WHILE ^ LPAREN ! expression RPAREN ! LCURLY ! instructions RCURLY !;
	public final StilParser.while_statement_return while_statement() throws RecognitionException {
		StilParser.while_statement_return retval = new StilParser.while_statement_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token WHILE30=null;
		Token LPAREN31=null;
		Token RPAREN33=null;
		Token LCURLY34=null;
		Token RCURLY36=null;
		ParserRuleReturnScope expression32 =null;
		ParserRuleReturnScope instructions35 =null;

		Object WHILE30_tree=null;
		Object LPAREN31_tree=null;
		Object RPAREN33_tree=null;
		Object LCURLY34_tree=null;
		Object RCURLY36_tree=null;

		try {
			// Stil.g:98:5: ( WHILE ^ LPAREN ! expression RPAREN ! LCURLY ! instructions RCURLY !)
			// Stil.g:98:9: WHILE ^ LPAREN ! expression RPAREN ! LCURLY ! instructions RCURLY !
			{
			root_0 = (Object)adaptor.nil();


			WHILE30=(Token)match(input,WHILE,FOLLOW_WHILE_in_while_statement1327); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			WHILE30_tree = (Object)adaptor.create(WHILE30);
			root_0 = (Object)adaptor.becomeRoot(WHILE30_tree, root_0);
			}

			LPAREN31=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_while_statement1330); if (state.failed) return retval;
			pushFollow(FOLLOW_expression_in_while_statement1333);
			expression32=expression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, expression32.getTree());

			RPAREN33=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_while_statement1335); if (state.failed) return retval;
			LCURLY34=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_while_statement1338); if (state.failed) return retval;
			pushFollow(FOLLOW_instructions_in_while_statement1341);
			instructions35=instructions();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, instructions35.getTree());

			RCURLY36=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_while_statement1343); if (state.failed) return retval;
			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "while_statement"


	public static class expression_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "expression"
	// Stil.g:101:1: expression : ( ( IDENTIFIER BECOMES )=> assignment_statement | arithmetic_expression );
	public final StilParser.expression_return expression() throws RecognitionException {
		StilParser.expression_return retval = new StilParser.expression_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		ParserRuleReturnScope assignment_statement37 =null;
		ParserRuleReturnScope arithmetic_expression38 =null;


		try {
			// Stil.g:102:5: ( ( IDENTIFIER BECOMES )=> assignment_statement | arithmetic_expression )
			int alt6=2;
			int LA6_0 = input.LA(1);
			if ( (LA6_0==IDENTIFIER) ) {
				int LA6_1 = input.LA(2);
				if ( (synpred1_Stil()) ) {
					alt6=1;
				}
				else if ( (true) ) {
					alt6=2;
				}

			}
			else if ( (LA6_0==CHAR_LITERAL||LA6_0==FALSE||(LA6_0 >= INT_LITERAL && LA6_0 <= LCURLY)||LA6_0==LPAREN||LA6_0==MINUS||LA6_0==NOT||(LA6_0 >= PLUS && LA6_0 <= PRINT)||LA6_0==READ||LA6_0==TRUE) ) {
				alt6=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 6, 0, input);
				throw nvae;
			}

			switch (alt6) {
				case 1 :
					// Stil.g:102:9: ( IDENTIFIER BECOMES )=> assignment_statement
					{
					root_0 = (Object)adaptor.nil();


					pushFollow(FOLLOW_assignment_statement_in_expression1374);
					assignment_statement37=assignment_statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment_statement37.getTree());

					}
					break;
				case 2 :
					// Stil.g:103:9: arithmetic_expression
					{
					root_0 = (Object)adaptor.nil();


					pushFollow(FOLLOW_arithmetic_expression_in_expression1384);
					arithmetic_expression38=arithmetic_expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression38.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "expression"


	public static class compound_expression_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "compound_expression"
	// Stil.g:106:1: compound_expression : ( ( ( declaration SEMICOLON !) | statement )* expression SEMICOLON !)+ ;
	public final StilParser.compound_expression_return compound_expression() throws RecognitionException {
		StilParser.compound_expression_return retval = new StilParser.compound_expression_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token SEMICOLON40=null;
		Token SEMICOLON43=null;
		ParserRuleReturnScope declaration39 =null;
		ParserRuleReturnScope statement41 =null;
		ParserRuleReturnScope expression42 =null;

		Object SEMICOLON40_tree=null;
		Object SEMICOLON43_tree=null;

		try {
			// Stil.g:107:5: ( ( ( ( declaration SEMICOLON !) | statement )* expression SEMICOLON !)+ )
			// Stil.g:107:9: ( ( ( declaration SEMICOLON !) | statement )* expression SEMICOLON !)+
			{
			root_0 = (Object)adaptor.nil();


			// Stil.g:107:9: ( ( ( declaration SEMICOLON !) | statement )* expression SEMICOLON !)+
			int cnt8=0;
			loop8:
			while (true) {
				int alt8=2;
				int LA8_0 = input.LA(1);
				if ( (LA8_0==CHAR_LITERAL||LA8_0==CONST||LA8_0==FALSE||(LA8_0 >= IDENTIFIER && LA8_0 <= IF)||(LA8_0 >= INT_LITERAL && LA8_0 <= LCURLY)||LA8_0==LPAREN||LA8_0==MINUS||LA8_0==NOT||(LA8_0 >= PLUS && LA8_0 <= PRINT)||LA8_0==READ||LA8_0==TRUE||(LA8_0 >= VAR && LA8_0 <= WHILE)) ) {
					alt8=1;
				}

				switch (alt8) {
				case 1 :
					// Stil.g:107:10: ( ( declaration SEMICOLON !) | statement )* expression SEMICOLON !
					{
					// Stil.g:107:10: ( ( declaration SEMICOLON !) | statement )*
					loop7:
					while (true) {
						int alt7=3;
						int LA7_0 = input.LA(1);
						if ( (LA7_0==CONST||LA7_0==VAR) ) {
							alt7=1;
						}
						else if ( (LA7_0==IF||LA7_0==WHILE) ) {
							alt7=2;
						}

						switch (alt7) {
						case 1 :
							// Stil.g:107:11: ( declaration SEMICOLON !)
							{
							// Stil.g:107:11: ( declaration SEMICOLON !)
							// Stil.g:107:12: declaration SEMICOLON !
							{
							pushFollow(FOLLOW_declaration_in_compound_expression1406);
							declaration39=declaration();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) adaptor.addChild(root_0, declaration39.getTree());

							SEMICOLON40=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_compound_expression1408); if (state.failed) return retval;
							}

							}
							break;
						case 2 :
							// Stil.g:107:38: statement
							{
							pushFollow(FOLLOW_statement_in_compound_expression1414);
							statement41=statement();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) adaptor.addChild(root_0, statement41.getTree());

							}
							break;

						default :
							break loop7;
						}
					}

					pushFollow(FOLLOW_expression_in_compound_expression1418);
					expression42=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, expression42.getTree());

					SEMICOLON43=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_compound_expression1420); if (state.failed) return retval;
					}
					break;

				default :
					if ( cnt8 >= 1 ) break loop8;
					if (state.backtracking>0) {state.failed=true; return retval;}
					EarlyExitException eee = new EarlyExitException(8, input);
					throw eee;
				}
				cnt8++;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "compound_expression"


	public static class closed_compound_expression_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "closed_compound_expression"
	// Stil.g:110:1: closed_compound_expression : LCURLY compound_expression RCURLY -> ^( COMPOUND_EXPR compound_expression ) ;
	public final StilParser.closed_compound_expression_return closed_compound_expression() throws RecognitionException {
		StilParser.closed_compound_expression_return retval = new StilParser.closed_compound_expression_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token LCURLY44=null;
		Token RCURLY46=null;
		ParserRuleReturnScope compound_expression45 =null;

		Object LCURLY44_tree=null;
		Object RCURLY46_tree=null;
		RewriteRuleTokenStream stream_LCURLY=new RewriteRuleTokenStream(adaptor,"token LCURLY");
		RewriteRuleTokenStream stream_RCURLY=new RewriteRuleTokenStream(adaptor,"token RCURLY");
		RewriteRuleSubtreeStream stream_compound_expression=new RewriteRuleSubtreeStream(adaptor,"rule compound_expression");

		try {
			// Stil.g:111:5: ( LCURLY compound_expression RCURLY -> ^( COMPOUND_EXPR compound_expression ) )
			// Stil.g:111:9: LCURLY compound_expression RCURLY
			{
			LCURLY44=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_closed_compound_expression1442); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LCURLY.add(LCURLY44);

			pushFollow(FOLLOW_compound_expression_in_closed_compound_expression1444);
			compound_expression45=compound_expression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_compound_expression.add(compound_expression45.getTree());
			RCURLY46=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_closed_compound_expression1446); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RCURLY.add(RCURLY46);

			// AST REWRITE
			// elements: compound_expression
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (Object)adaptor.nil();
			// 111:43: -> ^( COMPOUND_EXPR compound_expression )
			{
				// Stil.g:111:46: ^( COMPOUND_EXPR compound_expression )
				{
				Object root_1 = (Object)adaptor.nil();
				root_1 = (Object)adaptor.becomeRoot(new ExprNode(COMPOUND_EXPR), root_1);
				adaptor.addChild(root_1, stream_compound_expression.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "closed_compound_expression"


	public static class arithmetic_expression_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "arithmetic_expression"
	// Stil.g:115:1: arithmetic_expression : arithmetic_expression_pr5 ( OR ^ arithmetic_expression_pr5 )* ;
	public final StilParser.arithmetic_expression_return arithmetic_expression() throws RecognitionException {
		StilParser.arithmetic_expression_return retval = new StilParser.arithmetic_expression_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token OR48=null;
		ParserRuleReturnScope arithmetic_expression_pr547 =null;
		ParserRuleReturnScope arithmetic_expression_pr549 =null;

		Object OR48_tree=null;

		try {
			// Stil.g:116:5: ( arithmetic_expression_pr5 ( OR ^ arithmetic_expression_pr5 )* )
			// Stil.g:116:9: arithmetic_expression_pr5 ( OR ^ arithmetic_expression_pr5 )*
			{
			root_0 = (Object)adaptor.nil();


			pushFollow(FOLLOW_arithmetic_expression_pr5_in_arithmetic_expression1477);
			arithmetic_expression_pr547=arithmetic_expression_pr5();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression_pr547.getTree());

			// Stil.g:116:35: ( OR ^ arithmetic_expression_pr5 )*
			loop9:
			while (true) {
				int alt9=2;
				int LA9_0 = input.LA(1);
				if ( (LA9_0==OR) ) {
					alt9=1;
				}

				switch (alt9) {
				case 1 :
					// Stil.g:116:36: OR ^ arithmetic_expression_pr5
					{
					OR48=(Token)match(input,OR,FOLLOW_OR_in_arithmetic_expression1480); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					OR48_tree = new LogicExprNode(OR48) ;
					root_0 = (Object)adaptor.becomeRoot(OR48_tree, root_0);
					}

					pushFollow(FOLLOW_arithmetic_expression_pr5_in_arithmetic_expression1486);
					arithmetic_expression_pr549=arithmetic_expression_pr5();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression_pr549.getTree());

					}
					break;

				default :
					break loop9;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "arithmetic_expression"


	public static class arithmetic_expression_pr5_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "arithmetic_expression_pr5"
	// Stil.g:119:1: arithmetic_expression_pr5 : arithmetic_expression_pr4 ( AND ^ arithmetic_expression_pr4 )* ;
	public final StilParser.arithmetic_expression_pr5_return arithmetic_expression_pr5() throws RecognitionException {
		StilParser.arithmetic_expression_pr5_return retval = new StilParser.arithmetic_expression_pr5_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token AND51=null;
		ParserRuleReturnScope arithmetic_expression_pr450 =null;
		ParserRuleReturnScope arithmetic_expression_pr452 =null;

		Object AND51_tree=null;

		try {
			// Stil.g:120:5: ( arithmetic_expression_pr4 ( AND ^ arithmetic_expression_pr4 )* )
			// Stil.g:120:9: arithmetic_expression_pr4 ( AND ^ arithmetic_expression_pr4 )*
			{
			root_0 = (Object)adaptor.nil();


			pushFollow(FOLLOW_arithmetic_expression_pr4_in_arithmetic_expression_pr51507);
			arithmetic_expression_pr450=arithmetic_expression_pr4();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression_pr450.getTree());

			// Stil.g:120:35: ( AND ^ arithmetic_expression_pr4 )*
			loop10:
			while (true) {
				int alt10=2;
				int LA10_0 = input.LA(1);
				if ( (LA10_0==AND) ) {
					alt10=1;
				}

				switch (alt10) {
				case 1 :
					// Stil.g:120:36: AND ^ arithmetic_expression_pr4
					{
					AND51=(Token)match(input,AND,FOLLOW_AND_in_arithmetic_expression_pr51510); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					AND51_tree = new LogicExprNode(AND51) ;
					root_0 = (Object)adaptor.becomeRoot(AND51_tree, root_0);
					}

					pushFollow(FOLLOW_arithmetic_expression_pr4_in_arithmetic_expression_pr51516);
					arithmetic_expression_pr452=arithmetic_expression_pr4();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression_pr452.getTree());

					}
					break;

				default :
					break loop10;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "arithmetic_expression_pr5"


	public static class arithmetic_expression_pr4_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "arithmetic_expression_pr4"
	// Stil.g:123:1: arithmetic_expression_pr4 : arithmetic_expression_pr3 ( ( LT ^| LTE ^| GT ^| GTE ^| EQ ^| NEQ ^) arithmetic_expression_pr3 )* ;
	public final StilParser.arithmetic_expression_pr4_return arithmetic_expression_pr4() throws RecognitionException {
		StilParser.arithmetic_expression_pr4_return retval = new StilParser.arithmetic_expression_pr4_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token LT54=null;
		Token LTE55=null;
		Token GT56=null;
		Token GTE57=null;
		Token EQ58=null;
		Token NEQ59=null;
		ParserRuleReturnScope arithmetic_expression_pr353 =null;
		ParserRuleReturnScope arithmetic_expression_pr360 =null;

		Object LT54_tree=null;
		Object LTE55_tree=null;
		Object GT56_tree=null;
		Object GTE57_tree=null;
		Object EQ58_tree=null;
		Object NEQ59_tree=null;

		try {
			// Stil.g:124:5: ( arithmetic_expression_pr3 ( ( LT ^| LTE ^| GT ^| GTE ^| EQ ^| NEQ ^) arithmetic_expression_pr3 )* )
			// Stil.g:124:9: arithmetic_expression_pr3 ( ( LT ^| LTE ^| GT ^| GTE ^| EQ ^| NEQ ^) arithmetic_expression_pr3 )*
			{
			root_0 = (Object)adaptor.nil();


			pushFollow(FOLLOW_arithmetic_expression_pr3_in_arithmetic_expression_pr41537);
			arithmetic_expression_pr353=arithmetic_expression_pr3();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression_pr353.getTree());

			// Stil.g:124:35: ( ( LT ^| LTE ^| GT ^| GTE ^| EQ ^| NEQ ^) arithmetic_expression_pr3 )*
			loop12:
			while (true) {
				int alt12=2;
				int LA12_0 = input.LA(1);
				if ( (LA12_0==EQ||(LA12_0 >= GT && LA12_0 <= GTE)||(LA12_0 >= LT && LA12_0 <= LTE)||LA12_0==NEQ) ) {
					alt12=1;
				}

				switch (alt12) {
				case 1 :
					// Stil.g:124:36: ( LT ^| LTE ^| GT ^| GTE ^| EQ ^| NEQ ^) arithmetic_expression_pr3
					{
					// Stil.g:124:36: ( LT ^| LTE ^| GT ^| GTE ^| EQ ^| NEQ ^)
					int alt11=6;
					switch ( input.LA(1) ) {
					case LT:
						{
						alt11=1;
						}
						break;
					case LTE:
						{
						alt11=2;
						}
						break;
					case GT:
						{
						alt11=3;
						}
						break;
					case GTE:
						{
						alt11=4;
						}
						break;
					case EQ:
						{
						alt11=5;
						}
						break;
					case NEQ:
						{
						alt11=6;
						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 11, 0, input);
						throw nvae;
					}
					switch (alt11) {
						case 1 :
							// Stil.g:124:37: LT ^
							{
							LT54=(Token)match(input,LT,FOLLOW_LT_in_arithmetic_expression_pr41541); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							LT54_tree = new LogicExprNode(LT54) ;
							root_0 = (Object)adaptor.becomeRoot(LT54_tree, root_0);
							}

							}
							break;
						case 2 :
							// Stil.g:124:58: LTE ^
							{
							LTE55=(Token)match(input,LTE,FOLLOW_LTE_in_arithmetic_expression_pr41549); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							LTE55_tree = new LogicExprNode(LTE55) ;
							root_0 = (Object)adaptor.becomeRoot(LTE55_tree, root_0);
							}

							}
							break;
						case 3 :
							// Stil.g:124:80: GT ^
							{
							GT56=(Token)match(input,GT,FOLLOW_GT_in_arithmetic_expression_pr41557); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							GT56_tree = new LogicExprNode(GT56) ;
							root_0 = (Object)adaptor.becomeRoot(GT56_tree, root_0);
							}

							}
							break;
						case 4 :
							// Stil.g:124:101: GTE ^
							{
							GTE57=(Token)match(input,GTE,FOLLOW_GTE_in_arithmetic_expression_pr41565); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							GTE57_tree = new LogicExprNode(GTE57) ;
							root_0 = (Object)adaptor.becomeRoot(GTE57_tree, root_0);
							}

							}
							break;
						case 5 :
							// Stil.g:124:123: EQ ^
							{
							EQ58=(Token)match(input,EQ,FOLLOW_EQ_in_arithmetic_expression_pr41573); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							EQ58_tree = new LogicExprNode(EQ58) ;
							root_0 = (Object)adaptor.becomeRoot(EQ58_tree, root_0);
							}

							}
							break;
						case 6 :
							// Stil.g:124:144: NEQ ^
							{
							NEQ59=(Token)match(input,NEQ,FOLLOW_NEQ_in_arithmetic_expression_pr41581); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							NEQ59_tree = new LogicExprNode(NEQ59) ;
							root_0 = (Object)adaptor.becomeRoot(NEQ59_tree, root_0);
							}

							}
							break;

					}

					pushFollow(FOLLOW_arithmetic_expression_pr3_in_arithmetic_expression_pr41588);
					arithmetic_expression_pr360=arithmetic_expression_pr3();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression_pr360.getTree());

					}
					break;

				default :
					break loop12;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "arithmetic_expression_pr4"


	public static class arithmetic_expression_pr3_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "arithmetic_expression_pr3"
	// Stil.g:127:1: arithmetic_expression_pr3 : arithmetic_expression_pr2 ( ( PLUS ^| MINUS ^) arithmetic_expression_pr2 )* ;
	public final StilParser.arithmetic_expression_pr3_return arithmetic_expression_pr3() throws RecognitionException {
		StilParser.arithmetic_expression_pr3_return retval = new StilParser.arithmetic_expression_pr3_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token PLUS62=null;
		Token MINUS63=null;
		ParserRuleReturnScope arithmetic_expression_pr261 =null;
		ParserRuleReturnScope arithmetic_expression_pr264 =null;

		Object PLUS62_tree=null;
		Object MINUS63_tree=null;

		try {
			// Stil.g:128:5: ( arithmetic_expression_pr2 ( ( PLUS ^| MINUS ^) arithmetic_expression_pr2 )* )
			// Stil.g:128:9: arithmetic_expression_pr2 ( ( PLUS ^| MINUS ^) arithmetic_expression_pr2 )*
			{
			root_0 = (Object)adaptor.nil();


			pushFollow(FOLLOW_arithmetic_expression_pr2_in_arithmetic_expression_pr31609);
			arithmetic_expression_pr261=arithmetic_expression_pr2();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression_pr261.getTree());

			// Stil.g:128:35: ( ( PLUS ^| MINUS ^) arithmetic_expression_pr2 )*
			loop14:
			while (true) {
				int alt14=2;
				int LA14_0 = input.LA(1);
				if ( (LA14_0==MINUS||LA14_0==PLUS) ) {
					alt14=1;
				}

				switch (alt14) {
				case 1 :
					// Stil.g:128:36: ( PLUS ^| MINUS ^) arithmetic_expression_pr2
					{
					// Stil.g:128:36: ( PLUS ^| MINUS ^)
					int alt13=2;
					int LA13_0 = input.LA(1);
					if ( (LA13_0==PLUS) ) {
						alt13=1;
					}
					else if ( (LA13_0==MINUS) ) {
						alt13=2;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 13, 0, input);
						throw nvae;
					}

					switch (alt13) {
						case 1 :
							// Stil.g:128:37: PLUS ^
							{
							PLUS62=(Token)match(input,PLUS,FOLLOW_PLUS_in_arithmetic_expression_pr31613); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							PLUS62_tree = new LogicExprNode(PLUS62) ;
							root_0 = (Object)adaptor.becomeRoot(PLUS62_tree, root_0);
							}

							}
							break;
						case 2 :
							// Stil.g:128:60: MINUS ^
							{
							MINUS63=(Token)match(input,MINUS,FOLLOW_MINUS_in_arithmetic_expression_pr31621); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							MINUS63_tree = new LogicExprNode(MINUS63) ;
							root_0 = (Object)adaptor.becomeRoot(MINUS63_tree, root_0);
							}

							}
							break;

					}

					pushFollow(FOLLOW_arithmetic_expression_pr2_in_arithmetic_expression_pr31628);
					arithmetic_expression_pr264=arithmetic_expression_pr2();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression_pr264.getTree());

					}
					break;

				default :
					break loop14;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "arithmetic_expression_pr3"


	public static class arithmetic_expression_pr2_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "arithmetic_expression_pr2"
	// Stil.g:131:1: arithmetic_expression_pr2 : arithmetic_expression_pr1 ( ( DIVIDE ^| MULTIPLY ^| MODULO ^) arithmetic_expression_pr1 )* ;
	public final StilParser.arithmetic_expression_pr2_return arithmetic_expression_pr2() throws RecognitionException {
		StilParser.arithmetic_expression_pr2_return retval = new StilParser.arithmetic_expression_pr2_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token DIVIDE66=null;
		Token MULTIPLY67=null;
		Token MODULO68=null;
		ParserRuleReturnScope arithmetic_expression_pr165 =null;
		ParserRuleReturnScope arithmetic_expression_pr169 =null;

		Object DIVIDE66_tree=null;
		Object MULTIPLY67_tree=null;
		Object MODULO68_tree=null;

		try {
			// Stil.g:132:5: ( arithmetic_expression_pr1 ( ( DIVIDE ^| MULTIPLY ^| MODULO ^) arithmetic_expression_pr1 )* )
			// Stil.g:132:9: arithmetic_expression_pr1 ( ( DIVIDE ^| MULTIPLY ^| MODULO ^) arithmetic_expression_pr1 )*
			{
			root_0 = (Object)adaptor.nil();


			pushFollow(FOLLOW_arithmetic_expression_pr1_in_arithmetic_expression_pr21649);
			arithmetic_expression_pr165=arithmetic_expression_pr1();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression_pr165.getTree());

			// Stil.g:132:35: ( ( DIVIDE ^| MULTIPLY ^| MODULO ^) arithmetic_expression_pr1 )*
			loop16:
			while (true) {
				int alt16=2;
				int LA16_0 = input.LA(1);
				if ( (LA16_0==DIVIDE||(LA16_0 >= MODULO && LA16_0 <= MULTIPLY)) ) {
					alt16=1;
				}

				switch (alt16) {
				case 1 :
					// Stil.g:132:36: ( DIVIDE ^| MULTIPLY ^| MODULO ^) arithmetic_expression_pr1
					{
					// Stil.g:132:36: ( DIVIDE ^| MULTIPLY ^| MODULO ^)
					int alt15=3;
					switch ( input.LA(1) ) {
					case DIVIDE:
						{
						alt15=1;
						}
						break;
					case MULTIPLY:
						{
						alt15=2;
						}
						break;
					case MODULO:
						{
						alt15=3;
						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 15, 0, input);
						throw nvae;
					}
					switch (alt15) {
						case 1 :
							// Stil.g:132:37: DIVIDE ^
							{
							DIVIDE66=(Token)match(input,DIVIDE,FOLLOW_DIVIDE_in_arithmetic_expression_pr21653); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							DIVIDE66_tree = new LogicExprNode(DIVIDE66) ;
							root_0 = (Object)adaptor.becomeRoot(DIVIDE66_tree, root_0);
							}

							}
							break;
						case 2 :
							// Stil.g:132:62: MULTIPLY ^
							{
							MULTIPLY67=(Token)match(input,MULTIPLY,FOLLOW_MULTIPLY_in_arithmetic_expression_pr21661); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							MULTIPLY67_tree = new LogicExprNode(MULTIPLY67) ;
							root_0 = (Object)adaptor.becomeRoot(MULTIPLY67_tree, root_0);
							}

							}
							break;
						case 3 :
							// Stil.g:132:89: MODULO ^
							{
							MODULO68=(Token)match(input,MODULO,FOLLOW_MODULO_in_arithmetic_expression_pr21669); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							MODULO68_tree = new LogicExprNode(MODULO68) ;
							root_0 = (Object)adaptor.becomeRoot(MODULO68_tree, root_0);
							}

							}
							break;

					}

					pushFollow(FOLLOW_arithmetic_expression_pr1_in_arithmetic_expression_pr21676);
					arithmetic_expression_pr169=arithmetic_expression_pr1();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expression_pr169.getTree());

					}
					break;

				default :
					break loop16;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "arithmetic_expression_pr2"


	public static class arithmetic_expression_pr1_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "arithmetic_expression_pr1"
	// Stil.g:135:1: arithmetic_expression_pr1 : ( PLUS operand -> ^( UNARY_PLUS operand ) | MINUS operand -> ^( UNARY_MINUS operand ) | NOT operand -> ^( UNARY_NOT operand ) | operand );
	public final StilParser.arithmetic_expression_pr1_return arithmetic_expression_pr1() throws RecognitionException {
		StilParser.arithmetic_expression_pr1_return retval = new StilParser.arithmetic_expression_pr1_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token PLUS70=null;
		Token MINUS72=null;
		Token NOT74=null;
		ParserRuleReturnScope operand71 =null;
		ParserRuleReturnScope operand73 =null;
		ParserRuleReturnScope operand75 =null;
		ParserRuleReturnScope operand76 =null;

		Object PLUS70_tree=null;
		Object MINUS72_tree=null;
		Object NOT74_tree=null;
		RewriteRuleTokenStream stream_NOT=new RewriteRuleTokenStream(adaptor,"token NOT");
		RewriteRuleTokenStream stream_PLUS=new RewriteRuleTokenStream(adaptor,"token PLUS");
		RewriteRuleTokenStream stream_MINUS=new RewriteRuleTokenStream(adaptor,"token MINUS");
		RewriteRuleSubtreeStream stream_operand=new RewriteRuleSubtreeStream(adaptor,"rule operand");

		try {
			// Stil.g:136:5: ( PLUS operand -> ^( UNARY_PLUS operand ) | MINUS operand -> ^( UNARY_MINUS operand ) | NOT operand -> ^( UNARY_NOT operand ) | operand )
			int alt17=4;
			switch ( input.LA(1) ) {
			case PLUS:
				{
				alt17=1;
				}
				break;
			case MINUS:
				{
				alt17=2;
				}
				break;
			case NOT:
				{
				alt17=3;
				}
				break;
			case CHAR_LITERAL:
			case FALSE:
			case IDENTIFIER:
			case INT_LITERAL:
			case LCURLY:
			case LPAREN:
			case PRINT:
			case READ:
			case TRUE:
				{
				alt17=4;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 17, 0, input);
				throw nvae;
			}
			switch (alt17) {
				case 1 :
					// Stil.g:136:9: PLUS operand
					{
					PLUS70=(Token)match(input,PLUS,FOLLOW_PLUS_in_arithmetic_expression_pr11697); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_PLUS.add(PLUS70);

					pushFollow(FOLLOW_operand_in_arithmetic_expression_pr11699);
					operand71=operand();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_operand.add(operand71.getTree());
					// AST REWRITE
					// elements: operand
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (Object)adaptor.nil();
					// 136:25: -> ^( UNARY_PLUS operand )
					{
						// Stil.g:136:28: ^( UNARY_PLUS operand )
						{
						Object root_1 = (Object)adaptor.nil();
						root_1 = (Object)adaptor.becomeRoot(new LogicExprNode(UNARY_PLUS), root_1);
						adaptor.addChild(root_1, stream_operand.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 2 :
					// Stil.g:137:9: MINUS operand
					{
					MINUS72=(Token)match(input,MINUS,FOLLOW_MINUS_in_arithmetic_expression_pr11723); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_MINUS.add(MINUS72);

					pushFollow(FOLLOW_operand_in_arithmetic_expression_pr11725);
					operand73=operand();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_operand.add(operand73.getTree());
					// AST REWRITE
					// elements: operand
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (Object)adaptor.nil();
					// 137:25: -> ^( UNARY_MINUS operand )
					{
						// Stil.g:137:28: ^( UNARY_MINUS operand )
						{
						Object root_1 = (Object)adaptor.nil();
						root_1 = (Object)adaptor.becomeRoot(new LogicExprNode(UNARY_MINUS), root_1);
						adaptor.addChild(root_1, stream_operand.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 3 :
					// Stil.g:138:9: NOT operand
					{
					NOT74=(Token)match(input,NOT,FOLLOW_NOT_in_arithmetic_expression_pr11748); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_NOT.add(NOT74);

					pushFollow(FOLLOW_operand_in_arithmetic_expression_pr11750);
					operand75=operand();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_operand.add(operand75.getTree());
					// AST REWRITE
					// elements: operand
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (Object)adaptor.nil();
					// 138:25: -> ^( UNARY_NOT operand )
					{
						// Stil.g:138:28: ^( UNARY_NOT operand )
						{
						Object root_1 = (Object)adaptor.nil();
						root_1 = (Object)adaptor.becomeRoot(new LogicExprNode(UNARY_NOT), root_1);
						adaptor.addChild(root_1, stream_operand.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 4 :
					// Stil.g:139:9: operand
					{
					root_0 = (Object)adaptor.nil();


					pushFollow(FOLLOW_operand_in_arithmetic_expression_pr11775);
					operand76=operand();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, operand76.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "arithmetic_expression_pr1"


	public static class operand_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "operand"
	// Stil.g:142:1: operand : ( bool_literal | CHAR_LITERAL | INT_LITERAL | IDENTIFIER | LPAREN ! expression RPAREN !| print_statement | read_statement | closed_compound_expression );
	public final StilParser.operand_return operand() throws RecognitionException {
		StilParser.operand_return retval = new StilParser.operand_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token CHAR_LITERAL78=null;
		Token INT_LITERAL79=null;
		Token IDENTIFIER80=null;
		Token LPAREN81=null;
		Token RPAREN83=null;
		ParserRuleReturnScope bool_literal77 =null;
		ParserRuleReturnScope expression82 =null;
		ParserRuleReturnScope print_statement84 =null;
		ParserRuleReturnScope read_statement85 =null;
		ParserRuleReturnScope closed_compound_expression86 =null;

		Object CHAR_LITERAL78_tree=null;
		Object INT_LITERAL79_tree=null;
		Object IDENTIFIER80_tree=null;
		Object LPAREN81_tree=null;
		Object RPAREN83_tree=null;

		try {
			// Stil.g:143:5: ( bool_literal | CHAR_LITERAL | INT_LITERAL | IDENTIFIER | LPAREN ! expression RPAREN !| print_statement | read_statement | closed_compound_expression )
			int alt18=8;
			switch ( input.LA(1) ) {
			case FALSE:
			case TRUE:
				{
				alt18=1;
				}
				break;
			case CHAR_LITERAL:
				{
				alt18=2;
				}
				break;
			case INT_LITERAL:
				{
				alt18=3;
				}
				break;
			case IDENTIFIER:
				{
				alt18=4;
				}
				break;
			case LPAREN:
				{
				alt18=5;
				}
				break;
			case PRINT:
				{
				alt18=6;
				}
				break;
			case READ:
				{
				alt18=7;
				}
				break;
			case LCURLY:
				{
				alt18=8;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 18, 0, input);
				throw nvae;
			}
			switch (alt18) {
				case 1 :
					// Stil.g:143:9: bool_literal
					{
					root_0 = (Object)adaptor.nil();


					pushFollow(FOLLOW_bool_literal_in_operand1794);
					bool_literal77=bool_literal();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, bool_literal77.getTree());

					}
					break;
				case 2 :
					// Stil.g:144:9: CHAR_LITERAL
					{
					root_0 = (Object)adaptor.nil();


					CHAR_LITERAL78=(Token)match(input,CHAR_LITERAL,FOLLOW_CHAR_LITERAL_in_operand1804); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					CHAR_LITERAL78_tree = new LiteralNode(CHAR_LITERAL78) ;
					adaptor.addChild(root_0, CHAR_LITERAL78_tree);
					}

					}
					break;
				case 3 :
					// Stil.g:145:9: INT_LITERAL
					{
					root_0 = (Object)adaptor.nil();


					INT_LITERAL79=(Token)match(input,INT_LITERAL,FOLLOW_INT_LITERAL_in_operand1817); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					INT_LITERAL79_tree = new LiteralNode(INT_LITERAL79) ;
					adaptor.addChild(root_0, INT_LITERAL79_tree);
					}

					}
					break;
				case 4 :
					// Stil.g:146:9: IDENTIFIER
					{
					root_0 = (Object)adaptor.nil();


					IDENTIFIER80=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_operand1830); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					IDENTIFIER80_tree = new IdNode(IDENTIFIER80) ;
					adaptor.addChild(root_0, IDENTIFIER80_tree);
					}

					}
					break;
				case 5 :
					// Stil.g:147:9: LPAREN ! expression RPAREN !
					{
					root_0 = (Object)adaptor.nil();


					LPAREN81=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_operand1843); if (state.failed) return retval;
					pushFollow(FOLLOW_expression_in_operand1846);
					expression82=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, expression82.getTree());

					RPAREN83=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_operand1848); if (state.failed) return retval;
					}
					break;
				case 6 :
					// Stil.g:148:9: print_statement
					{
					root_0 = (Object)adaptor.nil();


					pushFollow(FOLLOW_print_statement_in_operand1859);
					print_statement84=print_statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, print_statement84.getTree());

					}
					break;
				case 7 :
					// Stil.g:149:9: read_statement
					{
					root_0 = (Object)adaptor.nil();


					pushFollow(FOLLOW_read_statement_in_operand1869);
					read_statement85=read_statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, read_statement85.getTree());

					}
					break;
				case 8 :
					// Stil.g:150:9: closed_compound_expression
					{
					root_0 = (Object)adaptor.nil();


					pushFollow(FOLLOW_closed_compound_expression_in_operand1879);
					closed_compound_expression86=closed_compound_expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, closed_compound_expression86.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "operand"


	public static class assignment_statement_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "assignment_statement"
	// Stil.g:153:1: assignment_statement : IDENTIFIER BECOMES ^ expression ;
	public final StilParser.assignment_statement_return assignment_statement() throws RecognitionException {
		StilParser.assignment_statement_return retval = new StilParser.assignment_statement_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token IDENTIFIER87=null;
		Token BECOMES88=null;
		ParserRuleReturnScope expression89 =null;

		Object IDENTIFIER87_tree=null;
		Object BECOMES88_tree=null;

		try {
			// Stil.g:154:5: ( IDENTIFIER BECOMES ^ expression )
			// Stil.g:154:9: IDENTIFIER BECOMES ^ expression
			{
			root_0 = (Object)adaptor.nil();


			IDENTIFIER87=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_assignment_statement1898); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			IDENTIFIER87_tree = new IdNode(IDENTIFIER87) ;
			adaptor.addChild(root_0, IDENTIFIER87_tree);
			}

			BECOMES88=(Token)match(input,BECOMES,FOLLOW_BECOMES_in_assignment_statement1903); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			BECOMES88_tree = new ExprNode(BECOMES88) ;
			root_0 = (Object)adaptor.becomeRoot(BECOMES88_tree, root_0);
			}

			pushFollow(FOLLOW_expression_in_assignment_statement1909);
			expression89=expression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, expression89.getTree());

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "assignment_statement"


	public static class print_statement_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "print_statement"
	// Stil.g:157:1: print_statement : PRINT ^ LPAREN ! expression ( COMMA ! expression )* RPAREN !;
	public final StilParser.print_statement_return print_statement() throws RecognitionException {
		StilParser.print_statement_return retval = new StilParser.print_statement_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token PRINT90=null;
		Token LPAREN91=null;
		Token COMMA93=null;
		Token RPAREN95=null;
		ParserRuleReturnScope expression92 =null;
		ParserRuleReturnScope expression94 =null;

		Object PRINT90_tree=null;
		Object LPAREN91_tree=null;
		Object COMMA93_tree=null;
		Object RPAREN95_tree=null;

		try {
			// Stil.g:158:5: ( PRINT ^ LPAREN ! expression ( COMMA ! expression )* RPAREN !)
			// Stil.g:158:9: PRINT ^ LPAREN ! expression ( COMMA ! expression )* RPAREN !
			{
			root_0 = (Object)adaptor.nil();


			PRINT90=(Token)match(input,PRINT,FOLLOW_PRINT_in_print_statement1928); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			PRINT90_tree = new ExprNode(PRINT90) ;
			root_0 = (Object)adaptor.becomeRoot(PRINT90_tree, root_0);
			}

			LPAREN91=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_print_statement1934); if (state.failed) return retval;
			pushFollow(FOLLOW_expression_in_print_statement1937);
			expression92=expression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, expression92.getTree());

			// Stil.g:158:45: ( COMMA ! expression )*
			loop19:
			while (true) {
				int alt19=2;
				int LA19_0 = input.LA(1);
				if ( (LA19_0==COMMA) ) {
					alt19=1;
				}

				switch (alt19) {
				case 1 :
					// Stil.g:158:46: COMMA ! expression
					{
					COMMA93=(Token)match(input,COMMA,FOLLOW_COMMA_in_print_statement1940); if (state.failed) return retval;
					pushFollow(FOLLOW_expression_in_print_statement1943);
					expression94=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, expression94.getTree());

					}
					break;

				default :
					break loop19;
				}
			}

			RPAREN95=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_print_statement1947); if (state.failed) return retval;
			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "print_statement"


	public static class read_statement_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "read_statement"
	// Stil.g:161:1: read_statement : READ ^ LPAREN ! IDENTIFIER ( COMMA ! IDENTIFIER )* RPAREN !;
	public final StilParser.read_statement_return read_statement() throws RecognitionException {
		StilParser.read_statement_return retval = new StilParser.read_statement_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token READ96=null;
		Token LPAREN97=null;
		Token IDENTIFIER98=null;
		Token COMMA99=null;
		Token IDENTIFIER100=null;
		Token RPAREN101=null;

		Object READ96_tree=null;
		Object LPAREN97_tree=null;
		Object IDENTIFIER98_tree=null;
		Object COMMA99_tree=null;
		Object IDENTIFIER100_tree=null;
		Object RPAREN101_tree=null;

		try {
			// Stil.g:162:5: ( READ ^ LPAREN ! IDENTIFIER ( COMMA ! IDENTIFIER )* RPAREN !)
			// Stil.g:162:9: READ ^ LPAREN ! IDENTIFIER ( COMMA ! IDENTIFIER )* RPAREN !
			{
			root_0 = (Object)adaptor.nil();


			READ96=(Token)match(input,READ,FOLLOW_READ_in_read_statement1967); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			READ96_tree = new ExprNode(READ96) ;
			root_0 = (Object)adaptor.becomeRoot(READ96_tree, root_0);
			}

			LPAREN97=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_read_statement1973); if (state.failed) return retval;
			IDENTIFIER98=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_read_statement1976); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			IDENTIFIER98_tree = new IdNode(IDENTIFIER98) ;
			adaptor.addChild(root_0, IDENTIFIER98_tree);
			}

			// Stil.g:162:52: ( COMMA ! IDENTIFIER )*
			loop20:
			while (true) {
				int alt20=2;
				int LA20_0 = input.LA(1);
				if ( (LA20_0==COMMA) ) {
					alt20=1;
				}

				switch (alt20) {
				case 1 :
					// Stil.g:162:53: COMMA ! IDENTIFIER
					{
					COMMA99=(Token)match(input,COMMA,FOLLOW_COMMA_in_read_statement1982); if (state.failed) return retval;
					IDENTIFIER100=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_read_statement1985); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					IDENTIFIER100_tree = new IdNode(IDENTIFIER100) ;
					adaptor.addChild(root_0, IDENTIFIER100_tree);
					}

					}
					break;

				default :
					break loop20;
				}
			}

			RPAREN101=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_read_statement1992); if (state.failed) return retval;
			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "read_statement"


	public static class type_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "type"
	// Stil.g:165:1: type : ( BOOL | CHAR | INT );
	public final StilParser.type_return type() throws RecognitionException {
		StilParser.type_return retval = new StilParser.type_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token set102=null;

		Object set102_tree=null;

		try {
			// Stil.g:166:5: ( BOOL | CHAR | INT )
			// Stil.g:
			{
			root_0 = (Object)adaptor.nil();


			set102=input.LT(1);
			if ( (input.LA(1) >= BOOL && input.LA(1) <= CHAR)||input.LA(1)==INT ) {
				input.consume();
				if ( state.backtracking==0 ) adaptor.addChild(root_0, (Object)adaptor.create(set102));
				state.errorRecovery=false;
				state.failed=false;
			}
			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				MismatchedSetException mse = new MismatchedSetException(null,input);
				throw mse;
			}
			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "type"


	public static class bool_literal_return extends ParserRuleReturnScope {
		Object tree;
		@Override
		public Object getTree() { return tree; }
	};


	// $ANTLR start "bool_literal"
	// Stil.g:169:1: bool_literal : ( TRUE | FALSE );
	public final StilParser.bool_literal_return bool_literal() throws RecognitionException {
		StilParser.bool_literal_return retval = new StilParser.bool_literal_return();
		retval.start = input.LT(1);

		Object root_0 = null;

		Token TRUE103=null;
		Token FALSE104=null;

		Object TRUE103_tree=null;
		Object FALSE104_tree=null;

		try {
			// Stil.g:170:5: ( TRUE | FALSE )
			int alt21=2;
			int LA21_0 = input.LA(1);
			if ( (LA21_0==TRUE) ) {
				alt21=1;
			}
			else if ( (LA21_0==FALSE) ) {
				alt21=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 21, 0, input);
				throw nvae;
			}

			switch (alt21) {
				case 1 :
					// Stil.g:170:9: TRUE
					{
					root_0 = (Object)adaptor.nil();


					TRUE103=(Token)match(input,TRUE,FOLLOW_TRUE_in_bool_literal2039); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					TRUE103_tree = new LiteralNode(TRUE103) ;
					adaptor.addChild(root_0, TRUE103_tree);
					}

					}
					break;
				case 2 :
					// Stil.g:171:9: FALSE
					{
					root_0 = (Object)adaptor.nil();


					FALSE104=(Token)match(input,FALSE,FOLLOW_FALSE_in_bool_literal2053); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					FALSE104_tree = new LiteralNode(FALSE104) ;
					adaptor.addChild(root_0, FALSE104_tree);
					}

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (Object)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "bool_literal"

	// $ANTLR start synpred1_Stil
	public final void synpred1_Stil_fragment() throws RecognitionException {
		// Stil.g:102:9: ( IDENTIFIER BECOMES )
		// Stil.g:102:10: IDENTIFIER BECOMES
		{
		match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_synpred1_Stil1364); if (state.failed) return;

		match(input,BECOMES,FOLLOW_BECOMES_in_synpred1_Stil1369); if (state.failed) return;

		}

	}
	// $ANTLR end synpred1_Stil

	// Delegated rules

	public final boolean synpred1_Stil() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred1_Stil_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}



	public static final BitSet FOLLOW_instructions_in_program1081 = new BitSet(new long[]{0x0000000000000000L});
	public static final BitSet FOLLOW_EOF_in_program1083 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_declaration_in_instructions1124 = new BitSet(new long[]{0x0000200000000000L});
	public static final BitSet FOLLOW_expression_in_instructions1128 = new BitSet(new long[]{0x0000200000000000L});
	public static final BitSet FOLLOW_SEMICOLON_in_instructions1131 = new BitSet(new long[]{0x001849A24D908402L});
	public static final BitSet FOLLOW_statement_in_instructions1137 = new BitSet(new long[]{0x001849A24D908402L});
	public static final BitSet FOLLOW_constant_declaration_in_declaration1158 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_var_declaration_in_declaration1169 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_CONST_in_constant_declaration1188 = new BitSet(new long[]{0x0000000002000180L});
	public static final BitSet FOLLOW_type_in_constant_declaration1194 = new BitSet(new long[]{0x0000000000800000L});
	public static final BitSet FOLLOW_IDENTIFIER_in_constant_declaration1196 = new BitSet(new long[]{0x0000000000000040L});
	public static final BitSet FOLLOW_BECOMES_in_constant_declaration1201 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_expression_in_constant_declaration1204 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_VAR_in_var_declaration1223 = new BitSet(new long[]{0x0000000002000180L});
	public static final BitSet FOLLOW_type_in_var_declaration1229 = new BitSet(new long[]{0x0000000000800000L});
	public static final BitSet FOLLOW_IDENTIFIER_in_var_declaration1231 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_if_statement_in_statement1254 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_while_statement_in_statement1258 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IF_in_if_statement1278 = new BitSet(new long[]{0x0000000040000000L});
	public static final BitSet FOLLOW_LPAREN_in_if_statement1281 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_expression_in_if_statement1284 = new BitSet(new long[]{0x0000100000000000L});
	public static final BitSet FOLLOW_RPAREN_in_if_statement1286 = new BitSet(new long[]{0x0000000008000000L});
	public static final BitSet FOLLOW_LCURLY_in_if_statement1289 = new BitSet(new long[]{0x00184DA24D908400L});
	public static final BitSet FOLLOW_instructions_in_if_statement1292 = new BitSet(new long[]{0x0000040000000000L});
	public static final BitSet FOLLOW_RCURLY_in_if_statement1294 = new BitSet(new long[]{0x0000000000040002L});
	public static final BitSet FOLLOW_ELSE_in_if_statement1298 = new BitSet(new long[]{0x0000000008000000L});
	public static final BitSet FOLLOW_LCURLY_in_if_statement1300 = new BitSet(new long[]{0x00184DA24D908400L});
	public static final BitSet FOLLOW_instructions_in_if_statement1303 = new BitSet(new long[]{0x0000040000000000L});
	public static final BitSet FOLLOW_RCURLY_in_if_statement1305 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_WHILE_in_while_statement1327 = new BitSet(new long[]{0x0000000040000000L});
	public static final BitSet FOLLOW_LPAREN_in_while_statement1330 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_expression_in_while_statement1333 = new BitSet(new long[]{0x0000100000000000L});
	public static final BitSet FOLLOW_RPAREN_in_while_statement1335 = new BitSet(new long[]{0x0000000008000000L});
	public static final BitSet FOLLOW_LCURLY_in_while_statement1338 = new BitSet(new long[]{0x00184DA24D908400L});
	public static final BitSet FOLLOW_instructions_in_while_statement1341 = new BitSet(new long[]{0x0000040000000000L});
	public static final BitSet FOLLOW_RCURLY_in_while_statement1343 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_assignment_statement_in_expression1374 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arithmetic_expression_in_expression1384 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_declaration_in_compound_expression1406 = new BitSet(new long[]{0x0000200000000000L});
	public static final BitSet FOLLOW_SEMICOLON_in_compound_expression1408 = new BitSet(new long[]{0x001849A24D908400L});
	public static final BitSet FOLLOW_statement_in_compound_expression1414 = new BitSet(new long[]{0x001849A24D908400L});
	public static final BitSet FOLLOW_expression_in_compound_expression1418 = new BitSet(new long[]{0x0000200000000000L});
	public static final BitSet FOLLOW_SEMICOLON_in_compound_expression1420 = new BitSet(new long[]{0x001849A24D908402L});
	public static final BitSet FOLLOW_LCURLY_in_closed_compound_expression1442 = new BitSet(new long[]{0x001849A24D908400L});
	public static final BitSet FOLLOW_compound_expression_in_closed_compound_expression1444 = new BitSet(new long[]{0x0000040000000000L});
	public static final BitSet FOLLOW_RCURLY_in_closed_compound_expression1446 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arithmetic_expression_pr5_in_arithmetic_expression1477 = new BitSet(new long[]{0x0000004000000002L});
	public static final BitSet FOLLOW_OR_in_arithmetic_expression1480 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_arithmetic_expression_pr5_in_arithmetic_expression1486 = new BitSet(new long[]{0x0000004000000002L});
	public static final BitSet FOLLOW_arithmetic_expression_pr4_in_arithmetic_expression_pr51507 = new BitSet(new long[]{0x0000000000000012L});
	public static final BitSet FOLLOW_AND_in_arithmetic_expression_pr51510 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_arithmetic_expression_pr4_in_arithmetic_expression_pr51516 = new BitSet(new long[]{0x0000000000000012L});
	public static final BitSet FOLLOW_arithmetic_expression_pr3_in_arithmetic_expression_pr41537 = new BitSet(new long[]{0x0000001180680002L});
	public static final BitSet FOLLOW_LT_in_arithmetic_expression_pr41541 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_LTE_in_arithmetic_expression_pr41549 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_GT_in_arithmetic_expression_pr41557 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_GTE_in_arithmetic_expression_pr41565 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_EQ_in_arithmetic_expression_pr41573 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_NEQ_in_arithmetic_expression_pr41581 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_arithmetic_expression_pr3_in_arithmetic_expression_pr41588 = new BitSet(new long[]{0x0000001180680002L});
	public static final BitSet FOLLOW_arithmetic_expression_pr2_in_arithmetic_expression_pr31609 = new BitSet(new long[]{0x0000008200000002L});
	public static final BitSet FOLLOW_PLUS_in_arithmetic_expression_pr31613 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_MINUS_in_arithmetic_expression_pr31621 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_arithmetic_expression_pr2_in_arithmetic_expression_pr31628 = new BitSet(new long[]{0x0000008200000002L});
	public static final BitSet FOLLOW_arithmetic_expression_pr1_in_arithmetic_expression_pr21649 = new BitSet(new long[]{0x0000000C00020002L});
	public static final BitSet FOLLOW_DIVIDE_in_arithmetic_expression_pr21653 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_MULTIPLY_in_arithmetic_expression_pr21661 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_MODULO_in_arithmetic_expression_pr21669 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_arithmetic_expression_pr1_in_arithmetic_expression_pr21676 = new BitSet(new long[]{0x0000000C00020002L});
	public static final BitSet FOLLOW_PLUS_in_arithmetic_expression_pr11697 = new BitSet(new long[]{0x000049004C900400L});
	public static final BitSet FOLLOW_operand_in_arithmetic_expression_pr11699 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_MINUS_in_arithmetic_expression_pr11723 = new BitSet(new long[]{0x000049004C900400L});
	public static final BitSet FOLLOW_operand_in_arithmetic_expression_pr11725 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_NOT_in_arithmetic_expression_pr11748 = new BitSet(new long[]{0x000049004C900400L});
	public static final BitSet FOLLOW_operand_in_arithmetic_expression_pr11750 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_operand_in_arithmetic_expression_pr11775 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_bool_literal_in_operand1794 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_CHAR_LITERAL_in_operand1804 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_INT_LITERAL_in_operand1817 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENTIFIER_in_operand1830 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LPAREN_in_operand1843 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_expression_in_operand1846 = new BitSet(new long[]{0x0000100000000000L});
	public static final BitSet FOLLOW_RPAREN_in_operand1848 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_print_statement_in_operand1859 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_read_statement_in_operand1869 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_closed_compound_expression_in_operand1879 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENTIFIER_in_assignment_statement1898 = new BitSet(new long[]{0x0000000000000040L});
	public static final BitSet FOLLOW_BECOMES_in_assignment_statement1903 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_expression_in_assignment_statement1909 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_PRINT_in_print_statement1928 = new BitSet(new long[]{0x0000000040000000L});
	public static final BitSet FOLLOW_LPAREN_in_print_statement1934 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_expression_in_print_statement1937 = new BitSet(new long[]{0x0000100000001000L});
	public static final BitSet FOLLOW_COMMA_in_print_statement1940 = new BitSet(new long[]{0x000049A24C900400L});
	public static final BitSet FOLLOW_expression_in_print_statement1943 = new BitSet(new long[]{0x0000100000001000L});
	public static final BitSet FOLLOW_RPAREN_in_print_statement1947 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_READ_in_read_statement1967 = new BitSet(new long[]{0x0000000040000000L});
	public static final BitSet FOLLOW_LPAREN_in_read_statement1973 = new BitSet(new long[]{0x0000000000800000L});
	public static final BitSet FOLLOW_IDENTIFIER_in_read_statement1976 = new BitSet(new long[]{0x0000100000001000L});
	public static final BitSet FOLLOW_COMMA_in_read_statement1982 = new BitSet(new long[]{0x0000000000800000L});
	public static final BitSet FOLLOW_IDENTIFIER_in_read_statement1985 = new BitSet(new long[]{0x0000100000001000L});
	public static final BitSet FOLLOW_RPAREN_in_read_statement1992 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_TRUE_in_bool_literal2039 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_FALSE_in_bool_literal2053 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENTIFIER_in_synpred1_Stil1364 = new BitSet(new long[]{0x0000000000000040L});
	public static final BitSet FOLLOW_BECOMES_in_synpred1_Stil1369 = new BitSet(new long[]{0x0000000000000002L});
}
