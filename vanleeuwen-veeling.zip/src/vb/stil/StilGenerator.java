// $ANTLR 3.5.2 StilGenerator.g 2014-07-09 16:07:36

    package vb.stil;
    import  vb.stil.codegenerator.*;
    import  vb.stil.symtab.*;
    import  vb.stil.tree.*;
    import  vb.stil.exceptions.*;
    import  org.stringtemplate.v4.*;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class StilGenerator extends TreeParser {
	public static final String[] tokenNames = new String[] {
		"<invalid>", "<EOR>", "<DOWN>", "<UP>", "AND", "APOS", "BECOMES", "BOOL", 
		"CHAR", "CHARALL", "CHAR_LITERAL", "COLON", "COMMA", "COMMENT", "COMPOUND_EXPR", 
		"CONST", "DIGIT", "DIVIDE", "ELSE", "EQ", "FALSE", "GT", "GTE", "IDENTIFIER", 
		"IF", "INT", "INT_LITERAL", "LCURLY", "LETTER", "LOWER", "LPAREN", "LT", 
		"LTE", "MINUS", "MODULO", "MULTIPLY", "NEQ", "NOT", "OR", "PLUS", "PRINT", 
		"PROGRAM", "RCURLY", "READ", "RPAREN", "SEMICOLON", "TRUE", "UNARY_MINUS", 
		"UNARY_NOT", "UNARY_PLUS", "UPPER", "VAR", "WHILE", "WS"
	};
	public static final int EOF=-1;
	public static final int AND=4;
	public static final int APOS=5;
	public static final int BECOMES=6;
	public static final int BOOL=7;
	public static final int CHAR=8;
	public static final int CHARALL=9;
	public static final int CHAR_LITERAL=10;
	public static final int COLON=11;
	public static final int COMMA=12;
	public static final int COMMENT=13;
	public static final int COMPOUND_EXPR=14;
	public static final int CONST=15;
	public static final int DIGIT=16;
	public static final int DIVIDE=17;
	public static final int ELSE=18;
	public static final int EQ=19;
	public static final int FALSE=20;
	public static final int GT=21;
	public static final int GTE=22;
	public static final int IDENTIFIER=23;
	public static final int IF=24;
	public static final int INT=25;
	public static final int INT_LITERAL=26;
	public static final int LCURLY=27;
	public static final int LETTER=28;
	public static final int LOWER=29;
	public static final int LPAREN=30;
	public static final int LT=31;
	public static final int LTE=32;
	public static final int MINUS=33;
	public static final int MODULO=34;
	public static final int MULTIPLY=35;
	public static final int NEQ=36;
	public static final int NOT=37;
	public static final int OR=38;
	public static final int PLUS=39;
	public static final int PRINT=40;
	public static final int PROGRAM=41;
	public static final int RCURLY=42;
	public static final int READ=43;
	public static final int RPAREN=44;
	public static final int SEMICOLON=45;
	public static final int TRUE=46;
	public static final int UNARY_MINUS=47;
	public static final int UNARY_NOT=48;
	public static final int UNARY_PLUS=49;
	public static final int UPPER=50;
	public static final int VAR=51;
	public static final int WHILE=52;
	public static final int WS=53;

	// delegates
	public TreeParser[] getDelegates() {
		return new TreeParser[] {};
	}

	// delegators


	public StilGenerator(TreeNodeStream input) {
		this(input, new RecognizerSharedState());
	}
	public StilGenerator(TreeNodeStream input, RecognizerSharedState state) {
		super(input, state);
	}

	@Override public String[] getTokenNames() { return StilGenerator.tokenNames; }
	@Override public String getGrammarFileName() { return "StilGenerator.g"; }


	    protected CodeGenerator codeGenerator = new CodeGenerator();



	// $ANTLR start "program"
	// StilGenerator.g:29:1: program[int numOps, int locals] returns [ST template = null] : ^( PROGRAM ( instruction )* ) ;
	public final ST program(int numOps, int locals) throws RecognitionException {
		ST template =  null;


		StilNode PROGRAM1=null;

		try {
			// StilGenerator.g:30:5: ( ^( PROGRAM ( instruction )* ) )
			// StilGenerator.g:30:9: ^( PROGRAM ( instruction )* )
			{
			PROGRAM1=(StilNode)match(input,PROGRAM,FOLLOW_PROGRAM_in_program102); 
			codeGenerator.openScope();
			if ( input.LA(1)==Token.DOWN ) {
				match(input, Token.DOWN, null); 
				// StilGenerator.g:32:13: ( instruction )*
				loop1:
				while (true) {
					int alt1=2;
					int LA1_0 = input.LA(1);
					if ( (LA1_0==AND||LA1_0==BECOMES||LA1_0==CHAR_LITERAL||(LA1_0 >= COMPOUND_EXPR && LA1_0 <= CONST)||LA1_0==DIVIDE||(LA1_0 >= EQ && LA1_0 <= IF)||LA1_0==INT_LITERAL||(LA1_0 >= LT && LA1_0 <= NEQ)||(LA1_0 >= OR && LA1_0 <= PRINT)||LA1_0==READ||(LA1_0 >= TRUE && LA1_0 <= UNARY_PLUS)||(LA1_0 >= VAR && LA1_0 <= WHILE)) ) {
						alt1=1;
					}

					switch (alt1) {
					case 1 :
						// StilGenerator.g:32:13: instruction
						{
						pushFollow(FOLLOW_instruction_in_program130);
						instruction();
						state._fsp--;

						}
						break;

					default :
						break loop1;
					}
				}

				match(input, Token.UP, null); 
			}

			 template = codeGenerator.processProgram((StilNode)PROGRAM1, numOps, locals); 
			codeGenerator.closeScope();
			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "program"



	// $ANTLR start "instruction"
	// StilGenerator.g:36:1: instruction returns [ST template = null] : (st= declaration |st= statement |st= expression );
	public final ST instruction() throws RecognitionException {
		ST template =  null;


		ST st =null;

		try {
			// StilGenerator.g:37:5: (st= declaration |st= statement |st= expression )
			int alt2=3;
			switch ( input.LA(1) ) {
			case CONST:
			case VAR:
				{
				alt2=1;
				}
				break;
			case IF:
			case WHILE:
				{
				alt2=2;
				}
				break;
			case AND:
			case BECOMES:
			case CHAR_LITERAL:
			case COMPOUND_EXPR:
			case DIVIDE:
			case EQ:
			case FALSE:
			case GT:
			case GTE:
			case IDENTIFIER:
			case INT_LITERAL:
			case LT:
			case LTE:
			case MINUS:
			case MODULO:
			case MULTIPLY:
			case NEQ:
			case OR:
			case PLUS:
			case PRINT:
			case READ:
			case TRUE:
			case UNARY_MINUS:
			case UNARY_NOT:
			case UNARY_PLUS:
				{
				alt2=3;
				}
				break;
			default:
				NoViableAltException nvae =
					new NoViableAltException("", 2, 0, input);
				throw nvae;
			}
			switch (alt2) {
				case 1 :
					// StilGenerator.g:37:9: st= declaration
					{
					pushFollow(FOLLOW_declaration_in_instruction173);
					st=declaration();
					state._fsp--;

					 template = st; 
					}
					break;
				case 2 :
					// StilGenerator.g:38:9: st= statement
					{
					pushFollow(FOLLOW_statement_in_instruction187);
					st=statement();
					state._fsp--;

					 template = st; 
					}
					break;
				case 3 :
					// StilGenerator.g:39:9: st= expression
					{
					pushFollow(FOLLOW_expression_in_instruction203);
					st=expression();
					state._fsp--;

					 template = st; 
					}
					break;

			}
		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "instruction"



	// $ANTLR start "declaration"
	// StilGenerator.g:42:1: declaration returns [ST template = null] : (st= var_declaration |st= constant_declaration );
	public final ST declaration() throws RecognitionException {
		ST template =  null;


		ST st =null;

		try {
			// StilGenerator.g:43:5: (st= var_declaration |st= constant_declaration )
			int alt3=2;
			int LA3_0 = input.LA(1);
			if ( (LA3_0==VAR) ) {
				alt3=1;
			}
			else if ( (LA3_0==CONST) ) {
				alt3=2;
			}

			else {
				NoViableAltException nvae =
					new NoViableAltException("", 3, 0, input);
				throw nvae;
			}

			switch (alt3) {
				case 1 :
					// StilGenerator.g:43:9: st= var_declaration
					{
					pushFollow(FOLLOW_var_declaration_in_declaration235);
					st=var_declaration();
					state._fsp--;

					 template = st; 
					}
					break;
				case 2 :
					// StilGenerator.g:44:9: st= constant_declaration
					{
					pushFollow(FOLLOW_constant_declaration_in_declaration254);
					st=constant_declaration();
					state._fsp--;

					 template = st; 
					}
					break;

			}
		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "declaration"



	// $ANTLR start "constant_declaration"
	// StilGenerator.g:47:1: constant_declaration returns [ST template = null] : ^( CONST type id= IDENTIFIER expression ) ;
	public final ST constant_declaration() throws RecognitionException {
		ST template =  null;


		StilNode id=null;
		StilNode CONST2=null;

		try {
			// StilGenerator.g:48:5: ( ^( CONST type id= IDENTIFIER expression ) )
			// StilGenerator.g:48:9: ^( CONST type id= IDENTIFIER expression )
			{
			CONST2=(StilNode)match(input,CONST,FOLLOW_CONST_in_constant_declaration280); 
			match(input, Token.DOWN, null); 
			pushFollow(FOLLOW_type_in_constant_declaration282);
			type();
			state._fsp--;

			id=(StilNode)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_constant_declaration286); 
			pushFollow(FOLLOW_expression_in_constant_declaration288);
			expression();
			state._fsp--;

			match(input, Token.UP, null); 

			 
			            template = codeGenerator.processConstDeclaration((DeclNode)CONST2, (IdNode)id); ((DeclNode)CONST2).setST(template); 
			        
			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "constant_declaration"



	// $ANTLR start "var_declaration"
	// StilGenerator.g:53:1: var_declaration returns [ST template = null] : ^( VAR type id= IDENTIFIER ) ;
	public final ST var_declaration() throws RecognitionException {
		ST template =  null;


		StilNode id=null;
		StilNode VAR3=null;

		try {
			// StilGenerator.g:54:5: ( ^( VAR type id= IDENTIFIER ) )
			// StilGenerator.g:54:9: ^( VAR type id= IDENTIFIER )
			{
			VAR3=(StilNode)match(input,VAR,FOLLOW_VAR_in_var_declaration315); 
			match(input, Token.DOWN, null); 
			pushFollow(FOLLOW_type_in_var_declaration317);
			type();
			state._fsp--;

			id=(StilNode)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_var_declaration321); 
			match(input, Token.UP, null); 

			 
			            template = codeGenerator.processVarDeclaration((DeclNode)VAR3, (IdNode)id); ((DeclNode)VAR3).setST(template); 
			        
			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "var_declaration"



	// $ANTLR start "statement"
	// StilGenerator.g:60:1: statement returns [ST template = null] : (st= if_statement |st= while_statement );
	public final ST statement() throws RecognitionException {
		ST template =  null;


		ST st =null;

		try {
			// StilGenerator.g:61:5: (st= if_statement |st= while_statement )
			int alt4=2;
			int LA4_0 = input.LA(1);
			if ( (LA4_0==IF) ) {
				alt4=1;
			}
			else if ( (LA4_0==WHILE) ) {
				alt4=2;
			}

			else {
				NoViableAltException nvae =
					new NoViableAltException("", 4, 0, input);
				throw nvae;
			}

			switch (alt4) {
				case 1 :
					// StilGenerator.g:61:9: st= if_statement
					{
					pushFollow(FOLLOW_if_statement_in_statement350);
					st=if_statement();
					state._fsp--;

					 template = st; 
					}
					break;
				case 2 :
					// StilGenerator.g:62:9: st= while_statement
					{
					pushFollow(FOLLOW_while_statement_in_statement367);
					st=while_statement();
					state._fsp--;

					 template = st; 
					}
					break;

			}
		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "statement"



	// $ANTLR start "if_statement"
	// StilGenerator.g:65:1: if_statement returns [ST template = null] : ^( IF expr= expression (i= instruction )* ( ELSE (i= instruction )* )? ) ;
	public final ST if_statement() throws RecognitionException {
		ST template =  null;


		StilNode IF4=null;
		ST expr =null;
		ST i =null;

		 List<ST> ifInstructions = new ArrayList<>(), elseInstructions = new ArrayList<>(); 
		try {
			// StilGenerator.g:67:5: ( ^( IF expr= expression (i= instruction )* ( ELSE (i= instruction )* )? ) )
			// StilGenerator.g:67:9: ^( IF expr= expression (i= instruction )* ( ELSE (i= instruction )* )? )
			{
			IF4=(StilNode)match(input,IF,FOLLOW_IF_in_if_statement405); 
			 codeGenerator.openScope();  
			match(input, Token.DOWN, null); 
			pushFollow(FOLLOW_expression_in_if_statement436);
			expr=expression();
			state._fsp--;

			// StilGenerator.g:69:13: (i= instruction )*
			loop5:
			while (true) {
				int alt5=2;
				int LA5_0 = input.LA(1);
				if ( (LA5_0==AND||LA5_0==BECOMES||LA5_0==CHAR_LITERAL||(LA5_0 >= COMPOUND_EXPR && LA5_0 <= CONST)||LA5_0==DIVIDE||(LA5_0 >= EQ && LA5_0 <= IF)||LA5_0==INT_LITERAL||(LA5_0 >= LT && LA5_0 <= NEQ)||(LA5_0 >= OR && LA5_0 <= PRINT)||LA5_0==READ||(LA5_0 >= TRUE && LA5_0 <= UNARY_PLUS)||(LA5_0 >= VAR && LA5_0 <= WHILE)) ) {
					alt5=1;
				}

				switch (alt5) {
				case 1 :
					// StilGenerator.g:69:14: i= instruction
					{
					pushFollow(FOLLOW_instruction_in_if_statement453);
					i=instruction();
					state._fsp--;

					 ifInstructions.add(i);      
					}
					break;

				default :
					break loop5;
				}
			}

			 codeGenerator.closeScope(); 
			// StilGenerator.g:71:10: ( ELSE (i= instruction )* )?
			int alt7=2;
			int LA7_0 = input.LA(1);
			if ( (LA7_0==ELSE) ) {
				alt7=1;
			}
			switch (alt7) {
				case 1 :
					// StilGenerator.g:71:13: ELSE (i= instruction )*
					{
					match(input,ELSE,FOLLOW_ELSE_in_if_statement508); 
					 codeGenerator.openScope();  
					// StilGenerator.g:72:13: (i= instruction )*
					loop6:
					while (true) {
						int alt6=2;
						int LA6_0 = input.LA(1);
						if ( (LA6_0==AND||LA6_0==BECOMES||LA6_0==CHAR_LITERAL||(LA6_0 >= COMPOUND_EXPR && LA6_0 <= CONST)||LA6_0==DIVIDE||(LA6_0 >= EQ && LA6_0 <= IF)||LA6_0==INT_LITERAL||(LA6_0 >= LT && LA6_0 <= NEQ)||(LA6_0 >= OR && LA6_0 <= PRINT)||LA6_0==READ||(LA6_0 >= TRUE && LA6_0 <= UNARY_PLUS)||(LA6_0 >= VAR && LA6_0 <= WHILE)) ) {
							alt6=1;
						}

						switch (alt6) {
						case 1 :
							// StilGenerator.g:72:14: i= instruction
							{
							pushFollow(FOLLOW_instruction_in_if_statement538);
							i=instruction();
							state._fsp--;

							 elseInstructions.add(i);    
							}
							break;

						default :
							break loop6;
						}
					}

					 codeGenerator.closeScope(); 
					}
					break;

			}

			match(input, Token.UP, null); 

			 template = codeGenerator.processIfStatement((StilNode)IF4, ifInstructions, elseInstructions); 
			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "if_statement"



	// $ANTLR start "while_statement"
	// StilGenerator.g:76:1: while_statement returns [ST template = null] : ^( WHILE expr= expression (i= instruction )* ) ;
	public final ST while_statement() throws RecognitionException {
		ST template =  null;


		StilNode WHILE5=null;
		ST expr =null;
		ST i =null;

		 List<ST> instructions = new ArrayList<>(); 
		try {
			// StilGenerator.g:78:5: ( ^( WHILE expr= expression (i= instruction )* ) )
			// StilGenerator.g:78:9: ^( WHILE expr= expression (i= instruction )* )
			{
			WHILE5=(StilNode)match(input,WHILE,FOLLOW_WHILE_in_while_statement622); 
			 codeGenerator.openScope();  
			match(input, Token.DOWN, null); 
			pushFollow(FOLLOW_expression_in_while_statement650);
			expr=expression();
			state._fsp--;

			// StilGenerator.g:80:13: (i= instruction )*
			loop8:
			while (true) {
				int alt8=2;
				int LA8_0 = input.LA(1);
				if ( (LA8_0==AND||LA8_0==BECOMES||LA8_0==CHAR_LITERAL||(LA8_0 >= COMPOUND_EXPR && LA8_0 <= CONST)||LA8_0==DIVIDE||(LA8_0 >= EQ && LA8_0 <= IF)||LA8_0==INT_LITERAL||(LA8_0 >= LT && LA8_0 <= NEQ)||(LA8_0 >= OR && LA8_0 <= PRINT)||LA8_0==READ||(LA8_0 >= TRUE && LA8_0 <= UNARY_PLUS)||(LA8_0 >= VAR && LA8_0 <= WHILE)) ) {
					alt8=1;
				}

				switch (alt8) {
				case 1 :
					// StilGenerator.g:80:14: i= instruction
					{
					pushFollow(FOLLOW_instruction_in_while_statement667);
					i=instruction();
					state._fsp--;

					 instructions.add(i);      
					}
					break;

				default :
					break loop8;
				}
			}

			 codeGenerator.closeScope(); 
			match(input, Token.UP, null); 

			 template = codeGenerator.processWhileStatement((StilNode)WHILE5, instructions); 
			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "while_statement"



	// $ANTLR start "print_statement"
	// StilGenerator.g:84:1: print_statement returns [ST template = null] : ^( PRINT ( expression )+ ) ;
	public final ST print_statement() throws RecognitionException {
		ST template =  null;


		StilNode PRINT6=null;

		try {
			// StilGenerator.g:85:5: ( ^( PRINT ( expression )+ ) )
			// StilGenerator.g:85:9: ^( PRINT ( expression )+ )
			{
			PRINT6=(StilNode)match(input,PRINT,FOLLOW_PRINT_in_print_statement735); 
			match(input, Token.DOWN, null); 
			// StilGenerator.g:85:17: ( expression )+
			int cnt9=0;
			loop9:
			while (true) {
				int alt9=2;
				int LA9_0 = input.LA(1);
				if ( (LA9_0==AND||LA9_0==BECOMES||LA9_0==CHAR_LITERAL||LA9_0==COMPOUND_EXPR||LA9_0==DIVIDE||(LA9_0 >= EQ && LA9_0 <= IDENTIFIER)||LA9_0==INT_LITERAL||(LA9_0 >= LT && LA9_0 <= NEQ)||(LA9_0 >= OR && LA9_0 <= PRINT)||LA9_0==READ||(LA9_0 >= TRUE && LA9_0 <= UNARY_PLUS)) ) {
					alt9=1;
				}

				switch (alt9) {
				case 1 :
					// StilGenerator.g:85:17: expression
					{
					pushFollow(FOLLOW_expression_in_print_statement737);
					expression();
					state._fsp--;

					}
					break;

				default :
					if ( cnt9 >= 1 ) break loop9;
					EarlyExitException eee = new EarlyExitException(9, input);
					throw eee;
				}
				cnt9++;
			}

			match(input, Token.UP, null); 

			 template = codeGenerator.processPrintStatement((ExprNode)PRINT6); 
			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "print_statement"



	// $ANTLR start "read_statement"
	// StilGenerator.g:88:1: read_statement returns [ST template = null;] : ^( READ ( IDENTIFIER )+ ) ;
	public final ST read_statement() throws RecognitionException {
		ST template =  null;;


		StilNode READ7=null;

		try {
			// StilGenerator.g:89:5: ( ^( READ ( IDENTIFIER )+ ) )
			// StilGenerator.g:89:9: ^( READ ( IDENTIFIER )+ )
			{
			READ7=(StilNode)match(input,READ,FOLLOW_READ_in_read_statement767); 
			match(input, Token.DOWN, null); 
			// StilGenerator.g:89:16: ( IDENTIFIER )+
			int cnt10=0;
			loop10:
			while (true) {
				int alt10=2;
				int LA10_0 = input.LA(1);
				if ( (LA10_0==IDENTIFIER) ) {
					alt10=1;
				}

				switch (alt10) {
				case 1 :
					// StilGenerator.g:89:16: IDENTIFIER
					{
					match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_read_statement769); 
					}
					break;

				default :
					if ( cnt10 >= 1 ) break loop10;
					EarlyExitException eee = new EarlyExitException(10, input);
					throw eee;
				}
				cnt10++;
			}

			match(input, Token.UP, null); 

			 template = codeGenerator.processReadStatement((ExprNode)READ7); 
			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "read_statement"



	// $ANTLR start "closed_compound_expression"
	// StilGenerator.g:92:1: closed_compound_expression returns [ST template = null] : ^( COMPOUND_EXPR ( ( declaration | statement )* expr= expression )* ) ;
	public final ST closed_compound_expression() throws RecognitionException {
		ST template =  null;


		StilNode COMPOUND_EXPR8=null;
		ST expr =null;

		try {
			// StilGenerator.g:93:5: ( ^( COMPOUND_EXPR ( ( declaration | statement )* expr= expression )* ) )
			// StilGenerator.g:93:9: ^( COMPOUND_EXPR ( ( declaration | statement )* expr= expression )* )
			{
			COMPOUND_EXPR8=(StilNode)match(input,COMPOUND_EXPR,FOLLOW_COMPOUND_EXPR_in_closed_compound_expression798); 
			 codeGenerator.openScope(); 
			if ( input.LA(1)==Token.DOWN ) {
				match(input, Token.DOWN, null); 
				// StilGenerator.g:94:13: ( ( declaration | statement )* expr= expression )*
				loop12:
				while (true) {
					int alt12=2;
					int LA12_0 = input.LA(1);
					if ( (LA12_0==AND||LA12_0==BECOMES||LA12_0==CHAR_LITERAL||(LA12_0 >= COMPOUND_EXPR && LA12_0 <= CONST)||LA12_0==DIVIDE||(LA12_0 >= EQ && LA12_0 <= IF)||LA12_0==INT_LITERAL||(LA12_0 >= LT && LA12_0 <= NEQ)||(LA12_0 >= OR && LA12_0 <= PRINT)||LA12_0==READ||(LA12_0 >= TRUE && LA12_0 <= UNARY_PLUS)||(LA12_0 >= VAR && LA12_0 <= WHILE)) ) {
						alt12=1;
					}

					switch (alt12) {
					case 1 :
						// StilGenerator.g:94:14: ( declaration | statement )* expr= expression
						{
						// StilGenerator.g:94:14: ( declaration | statement )*
						loop11:
						while (true) {
							int alt11=3;
							int LA11_0 = input.LA(1);
							if ( (LA11_0==CONST||LA11_0==VAR) ) {
								alt11=1;
							}
							else if ( (LA11_0==IF||LA11_0==WHILE) ) {
								alt11=2;
							}

							switch (alt11) {
							case 1 :
								// StilGenerator.g:94:15: declaration
								{
								pushFollow(FOLLOW_declaration_in_closed_compound_expression818);
								declaration();
								state._fsp--;

								}
								break;
							case 2 :
								// StilGenerator.g:94:29: statement
								{
								pushFollow(FOLLOW_statement_in_closed_compound_expression822);
								statement();
								state._fsp--;

								}
								break;

							default :
								break loop11;
							}
						}

						pushFollow(FOLLOW_expression_in_closed_compound_expression828);
						expr=expression();
						state._fsp--;

						}
						break;

					default :
						break loop12;
					}
				}

				 template = codeGenerator.processCompoundExpression((StilNode)COMPOUND_EXPR8);
				              codeGenerator.closeScope(); ((ExprNode)COMPOUND_EXPR8).setST(template);
				match(input, Token.UP, null); 
			}

			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "closed_compound_expression"



	// $ANTLR start "expression"
	// StilGenerator.g:100:1: expression returns [ST template = null] : (st= print_statement |st= read_statement |st= operand |st= closed_compound_expression | ^( BECOMES IDENTIFIER expression ) | ^(node= OR expression expression ) | ^(node= AND expression expression ) | ^(node= LT expression expression ) | ^(node= LTE expression expression ) | ^(node= GT expression expression ) | ^(node= GTE expression expression ) | ^(node= EQ expression expression ) | ^(node= NEQ expression expression ) | ^(node= PLUS expression expression ) | ^(node= MINUS expression expression ) | ^(node= DIVIDE expression expression ) | ^(node= MULTIPLY expression expression ) | ^(node= MODULO expression expression ) | ^(node= UNARY_PLUS expression ) | ^(node= UNARY_MINUS expression ) | ^(node= UNARY_NOT expression ) );
	public final ST expression() throws RecognitionException {
		ST template =  null;


		StilNode node=null;
		StilNode BECOMES9=null;
		ST st =null;

		try {
			// StilGenerator.g:101:5: (st= print_statement |st= read_statement |st= operand |st= closed_compound_expression | ^( BECOMES IDENTIFIER expression ) | ^(node= OR expression expression ) | ^(node= AND expression expression ) | ^(node= LT expression expression ) | ^(node= LTE expression expression ) | ^(node= GT expression expression ) | ^(node= GTE expression expression ) | ^(node= EQ expression expression ) | ^(node= NEQ expression expression ) | ^(node= PLUS expression expression ) | ^(node= MINUS expression expression ) | ^(node= DIVIDE expression expression ) | ^(node= MULTIPLY expression expression ) | ^(node= MODULO expression expression ) | ^(node= UNARY_PLUS expression ) | ^(node= UNARY_MINUS expression ) | ^(node= UNARY_NOT expression ) )
			int alt13=21;
			switch ( input.LA(1) ) {
			case PRINT:
				{
				alt13=1;
				}
				break;
			case READ:
				{
				alt13=2;
				}
				break;
			case CHAR_LITERAL:
			case FALSE:
			case IDENTIFIER:
			case INT_LITERAL:
			case TRUE:
				{
				alt13=3;
				}
				break;
			case COMPOUND_EXPR:
				{
				alt13=4;
				}
				break;
			case BECOMES:
				{
				alt13=5;
				}
				break;
			case OR:
				{
				alt13=6;
				}
				break;
			case AND:
				{
				alt13=7;
				}
				break;
			case LT:
				{
				alt13=8;
				}
				break;
			case LTE:
				{
				alt13=9;
				}
				break;
			case GT:
				{
				alt13=10;
				}
				break;
			case GTE:
				{
				alt13=11;
				}
				break;
			case EQ:
				{
				alt13=12;
				}
				break;
			case NEQ:
				{
				alt13=13;
				}
				break;
			case PLUS:
				{
				alt13=14;
				}
				break;
			case MINUS:
				{
				alt13=15;
				}
				break;
			case DIVIDE:
				{
				alt13=16;
				}
				break;
			case MULTIPLY:
				{
				alt13=17;
				}
				break;
			case MODULO:
				{
				alt13=18;
				}
				break;
			case UNARY_PLUS:
				{
				alt13=19;
				}
				break;
			case UNARY_MINUS:
				{
				alt13=20;
				}
				break;
			case UNARY_NOT:
				{
				alt13=21;
				}
				break;
			default:
				NoViableAltException nvae =
					new NoViableAltException("", 13, 0, input);
				throw nvae;
			}
			switch (alt13) {
				case 1 :
					// StilGenerator.g:101:9: st= print_statement
					{
					pushFollow(FOLLOW_print_statement_in_expression882);
					st=print_statement();
					state._fsp--;

					 template = st; 
					}
					break;
				case 2 :
					// StilGenerator.g:102:9: st= read_statement
					{
					pushFollow(FOLLOW_read_statement_in_expression911);
					st=read_statement();
					state._fsp--;

					 template = st; 
					}
					break;
				case 3 :
					// StilGenerator.g:103:9: st= operand
					{
					pushFollow(FOLLOW_operand_in_expression941);
					st=operand();
					state._fsp--;

					 template = st; 
					}
					break;
				case 4 :
					// StilGenerator.g:104:9: st= closed_compound_expression
					{
					pushFollow(FOLLOW_closed_compound_expression_in_expression978);
					st=closed_compound_expression();
					state._fsp--;

					 template = st; 
					}
					break;
				case 5 :
					// StilGenerator.g:105:9: ^( BECOMES IDENTIFIER expression )
					{
					BECOMES9=(StilNode)match(input,BECOMES,FOLLOW_BECOMES_in_expression995); 
					match(input, Token.DOWN, null); 
					match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_expression997); 
					pushFollow(FOLLOW_expression_in_expression999);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.becomes((ExprNode)BECOMES9); ((ExprNode)BECOMES9).setST(template);  
					}
					break;
				case 6 :
					// StilGenerator.g:106:9: ^(node= OR expression expression )
					{
					node=(StilNode)match(input,OR,FOLLOW_OR_in_expression1019); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1030);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1032);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node);  
					}
					break;
				case 7 :
					// StilGenerator.g:107:9: ^(node= AND expression expression )
					{
					node=(StilNode)match(input,AND,FOLLOW_AND_in_expression1048); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1058);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1060);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 8 :
					// StilGenerator.g:108:9: ^(node= LT expression expression )
					{
					node=(StilNode)match(input,LT,FOLLOW_LT_in_expression1076); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1087);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1089);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 9 :
					// StilGenerator.g:109:9: ^(node= LTE expression expression )
					{
					node=(StilNode)match(input,LTE,FOLLOW_LTE_in_expression1105); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1115);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1117);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 10 :
					// StilGenerator.g:110:9: ^(node= GT expression expression )
					{
					node=(StilNode)match(input,GT,FOLLOW_GT_in_expression1133); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1144);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1146);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 11 :
					// StilGenerator.g:111:9: ^(node= GTE expression expression )
					{
					node=(StilNode)match(input,GTE,FOLLOW_GTE_in_expression1162); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1172);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1174);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 12 :
					// StilGenerator.g:112:9: ^(node= EQ expression expression )
					{
					node=(StilNode)match(input,EQ,FOLLOW_EQ_in_expression1190); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1201);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1203);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 13 :
					// StilGenerator.g:113:9: ^(node= NEQ expression expression )
					{
					node=(StilNode)match(input,NEQ,FOLLOW_NEQ_in_expression1219); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1229);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1231);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 14 :
					// StilGenerator.g:114:9: ^(node= PLUS expression expression )
					{
					node=(StilNode)match(input,PLUS,FOLLOW_PLUS_in_expression1247); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1256);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1258);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 15 :
					// StilGenerator.g:115:9: ^(node= MINUS expression expression )
					{
					node=(StilNode)match(input,MINUS,FOLLOW_MINUS_in_expression1274); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1282);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1284);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 16 :
					// StilGenerator.g:116:9: ^(node= DIVIDE expression expression )
					{
					node=(StilNode)match(input,DIVIDE,FOLLOW_DIVIDE_in_expression1300); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1307);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1309);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 17 :
					// StilGenerator.g:117:9: ^(node= MULTIPLY expression expression )
					{
					node=(StilNode)match(input,MULTIPLY,FOLLOW_MULTIPLY_in_expression1325); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1330);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1332);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 18 :
					// StilGenerator.g:118:9: ^(node= MODULO expression expression )
					{
					node=(StilNode)match(input,MODULO,FOLLOW_MODULO_in_expression1348); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1355);
					expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1357);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processBinaryLogicExpression((LogicExprNode)node); 
					}
					break;
				case 19 :
					// StilGenerator.g:119:9: ^(node= UNARY_PLUS expression )
					{
					node=(StilNode)match(input,UNARY_PLUS,FOLLOW_UNARY_PLUS_in_expression1373); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1376);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processUnaryLogicExpression( (LogicExprNode)node); 
					}
					break;
				case 20 :
					// StilGenerator.g:120:9: ^(node= UNARY_MINUS expression )
					{
					node=(StilNode)match(input,UNARY_MINUS,FOLLOW_UNARY_MINUS_in_expression1403); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1405);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processUnaryLogicExpression( (LogicExprNode)node); 
					}
					break;
				case 21 :
					// StilGenerator.g:121:9: ^(node= UNARY_NOT expression )
					{
					node=(StilNode)match(input,UNARY_NOT,FOLLOW_UNARY_NOT_in_expression1432); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1436);
					expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 template = codeGenerator.processUnaryLogicExpression( (LogicExprNode)node); 
					}
					break;

			}
		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "expression"



	// $ANTLR start "operand"
	// StilGenerator.g:124:1: operand returns [ST template = null] : (id= IDENTIFIER |v= ( TRUE | FALSE ) |v= CHAR_LITERAL |v= INT_LITERAL );
	public final ST operand() throws RecognitionException {
		ST template =  null;


		StilNode id=null;
		StilNode v=null;

		try {
			// StilGenerator.g:125:5: (id= IDENTIFIER |v= ( TRUE | FALSE ) |v= CHAR_LITERAL |v= INT_LITERAL )
			int alt14=4;
			switch ( input.LA(1) ) {
			case IDENTIFIER:
				{
				alt14=1;
				}
				break;
			case FALSE:
			case TRUE:
				{
				alt14=2;
				}
				break;
			case CHAR_LITERAL:
				{
				alt14=3;
				}
				break;
			case INT_LITERAL:
				{
				alt14=4;
				}
				break;
			default:
				NoViableAltException nvae =
					new NoViableAltException("", 14, 0, input);
				throw nvae;
			}
			switch (alt14) {
				case 1 :
					// StilGenerator.g:125:9: id= IDENTIFIER
					{
					id=(StilNode)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_operand1475); 
					 template = codeGenerator.processIdOperand((IdNode)id); ((IdNode)id).setST(template); 
					}
					break;
				case 2 :
					// StilGenerator.g:126:9: v= ( TRUE | FALSE )
					{
					v=(StilNode)input.LT(1);
					if ( input.LA(1)==FALSE||input.LA(1)==TRUE ) {
						input.consume();
						state.errorRecovery=false;
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						throw mse;
					}
					 template = codeGenerator.processBoolLiteral((LiteralNode)v); ((LiteralNode)v).setST(template); 
					}
					break;
				case 3 :
					// StilGenerator.g:127:9: v= CHAR_LITERAL
					{
					v=(StilNode)match(input,CHAR_LITERAL,FOLLOW_CHAR_LITERAL_in_operand1518); 
					 template = codeGenerator.processCharLiteral((LiteralNode)v); ((LiteralNode)v).setST(template); 
					}
					break;
				case 4 :
					// StilGenerator.g:128:9: v= INT_LITERAL
					{
					v=(StilNode)match(input,INT_LITERAL,FOLLOW_INT_LITERAL_in_operand1537); 
					 template = codeGenerator.processIntLiteral((LiteralNode)v); ((LiteralNode)v).setST(template); 
					}
					break;

			}
		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return template;
	}
	// $ANTLR end "operand"



	// $ANTLR start "type"
	// StilGenerator.g:131:1: type : ( BOOL | CHAR | INT );
	public final void type() throws RecognitionException {
		try {
			// StilGenerator.g:132:5: ( BOOL | CHAR | INT )
			// StilGenerator.g:
			{
			if ( (input.LA(1) >= BOOL && input.LA(1) <= CHAR)||input.LA(1)==INT ) {
				input.consume();
				state.errorRecovery=false;
			}
			else {
				MismatchedSetException mse = new MismatchedSetException(null,input);
				throw mse;
			}
			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "type"

	// Delegated rules



	public static final BitSet FOLLOW_PROGRAM_in_program102 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_instruction_in_program130 = new BitSet(new long[]{0x001BC9DF85FAC458L});
	public static final BitSet FOLLOW_declaration_in_instruction173 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_statement_in_instruction187 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_expression_in_instruction203 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_var_declaration_in_declaration235 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_constant_declaration_in_declaration254 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_CONST_in_constant_declaration280 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_type_in_constant_declaration282 = new BitSet(new long[]{0x0000000000800000L});
	public static final BitSet FOLLOW_IDENTIFIER_in_constant_declaration286 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_constant_declaration288 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_VAR_in_var_declaration315 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_type_in_var_declaration317 = new BitSet(new long[]{0x0000000000800000L});
	public static final BitSet FOLLOW_IDENTIFIER_in_var_declaration321 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_if_statement_in_statement350 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_while_statement_in_statement367 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IF_in_if_statement405 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_if_statement436 = new BitSet(new long[]{0x001BC9DF85FEC458L});
	public static final BitSet FOLLOW_instruction_in_if_statement453 = new BitSet(new long[]{0x001BC9DF85FEC458L});
	public static final BitSet FOLLOW_ELSE_in_if_statement508 = new BitSet(new long[]{0x001BC9DF85FAC458L});
	public static final BitSet FOLLOW_instruction_in_if_statement538 = new BitSet(new long[]{0x001BC9DF85FAC458L});
	public static final BitSet FOLLOW_WHILE_in_while_statement622 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_while_statement650 = new BitSet(new long[]{0x001BC9DF85FAC458L});
	public static final BitSet FOLLOW_instruction_in_while_statement667 = new BitSet(new long[]{0x001BC9DF85FAC458L});
	public static final BitSet FOLLOW_PRINT_in_print_statement735 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_print_statement737 = new BitSet(new long[]{0x0003C9DF84FA4458L});
	public static final BitSet FOLLOW_READ_in_read_statement767 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_IDENTIFIER_in_read_statement769 = new BitSet(new long[]{0x0000000000800008L});
	public static final BitSet FOLLOW_COMPOUND_EXPR_in_closed_compound_expression798 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_declaration_in_closed_compound_expression818 = new BitSet(new long[]{0x001BC9DF85FAC450L});
	public static final BitSet FOLLOW_statement_in_closed_compound_expression822 = new BitSet(new long[]{0x001BC9DF85FAC450L});
	public static final BitSet FOLLOW_expression_in_closed_compound_expression828 = new BitSet(new long[]{0x001BC9DF85FAC458L});
	public static final BitSet FOLLOW_print_statement_in_expression882 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_read_statement_in_expression911 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_operand_in_expression941 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_closed_compound_expression_in_expression978 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_BECOMES_in_expression995 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_IDENTIFIER_in_expression997 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression999 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_OR_in_expression1019 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1030 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1032 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_AND_in_expression1048 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1058 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1060 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_LT_in_expression1076 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1087 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1089 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_LTE_in_expression1105 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1115 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1117 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_GT_in_expression1133 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1144 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1146 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_GTE_in_expression1162 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1172 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1174 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_EQ_in_expression1190 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1201 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1203 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_NEQ_in_expression1219 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1229 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1231 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_PLUS_in_expression1247 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1256 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1258 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_MINUS_in_expression1274 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1282 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1284 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_DIVIDE_in_expression1300 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1307 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1309 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_MULTIPLY_in_expression1325 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1330 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1332 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_MODULO_in_expression1348 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1355 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1357 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_UNARY_PLUS_in_expression1373 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1376 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_UNARY_MINUS_in_expression1403 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1405 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_UNARY_NOT_in_expression1432 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1436 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_IDENTIFIER_in_operand1475 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_set_in_operand1495 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_CHAR_LITERAL_in_operand1518 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_INT_LITERAL_in_operand1537 = new BitSet(new long[]{0x0000000000000002L});
}
