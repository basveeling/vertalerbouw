// $ANTLR 3.5.2 StilChecker.g 2014-07-09 16:07:36

    package vb.stil;
    import  vb.stil.checker.*;
    import  vb.stil.symtab.*;
    import  vb.stil.tree.*;
    import  vb.stil.exceptions.*;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class StilChecker extends TreeParser {
	public static final String[] tokenNames = new String[] {
		"<invalid>", "<EOR>", "<DOWN>", "<UP>", "AND", "APOS", "BECOMES", "BOOL", 
		"CHAR", "CHARALL", "CHAR_LITERAL", "COLON", "COMMA", "COMMENT", "COMPOUND_EXPR", 
		"CONST", "DIGIT", "DIVIDE", "ELSE", "EQ", "FALSE", "GT", "GTE", "IDENTIFIER", 
		"IF", "INT", "INT_LITERAL", "LCURLY", "LETTER", "LOWER", "LPAREN", "LT", 
		"LTE", "MINUS", "MODULO", "MULTIPLY", "NEQ", "NOT", "OR", "PLUS", "PRINT", 
		"PROGRAM", "RCURLY", "READ", "RPAREN", "SEMICOLON", "TRUE", "UNARY_MINUS", 
		"UNARY_NOT", "UNARY_PLUS", "UPPER", "VAR", "WHILE", "WS"
	};
	public static final int EOF=-1;
	public static final int AND=4;
	public static final int APOS=5;
	public static final int BECOMES=6;
	public static final int BOOL=7;
	public static final int CHAR=8;
	public static final int CHARALL=9;
	public static final int CHAR_LITERAL=10;
	public static final int COLON=11;
	public static final int COMMA=12;
	public static final int COMMENT=13;
	public static final int COMPOUND_EXPR=14;
	public static final int CONST=15;
	public static final int DIGIT=16;
	public static final int DIVIDE=17;
	public static final int ELSE=18;
	public static final int EQ=19;
	public static final int FALSE=20;
	public static final int GT=21;
	public static final int GTE=22;
	public static final int IDENTIFIER=23;
	public static final int IF=24;
	public static final int INT=25;
	public static final int INT_LITERAL=26;
	public static final int LCURLY=27;
	public static final int LETTER=28;
	public static final int LOWER=29;
	public static final int LPAREN=30;
	public static final int LT=31;
	public static final int LTE=32;
	public static final int MINUS=33;
	public static final int MODULO=34;
	public static final int MULTIPLY=35;
	public static final int NEQ=36;
	public static final int NOT=37;
	public static final int OR=38;
	public static final int PLUS=39;
	public static final int PRINT=40;
	public static final int PROGRAM=41;
	public static final int RCURLY=42;
	public static final int READ=43;
	public static final int RPAREN=44;
	public static final int SEMICOLON=45;
	public static final int TRUE=46;
	public static final int UNARY_MINUS=47;
	public static final int UNARY_NOT=48;
	public static final int UNARY_PLUS=49;
	public static final int UPPER=50;
	public static final int VAR=51;
	public static final int WHILE=52;
	public static final int WS=53;

	// delegates
	public TreeParser[] getDelegates() {
		return new TreeParser[] {};
	}

	// delegators


	public StilChecker(TreeNodeStream input) {
		this(input, new RecognizerSharedState());
	}
	public StilChecker(TreeNodeStream input, RecognizerSharedState state) {
		super(input, state);
	}

	@Override public String[] getTokenNames() { return StilChecker.tokenNames; }
	@Override public String getGrammarFileName() { return "StilChecker.g"; }


	    protected SymbolTable<IdEntry> symtab = new SymbolTable<>();
	    protected DeclarationChecker declarationChecker = new DeclarationChecker();
	    protected TypeChecker typeChecker = new TypeChecker();



	// $ANTLR start "program"
	// StilChecker.g:30:1: program : ^( PROGRAM instructions ) ;
	public final void program() throws RecognitionException {
		try {
			// StilChecker.g:31:5: ( ^( PROGRAM instructions ) )
			// StilChecker.g:31:9: ^( PROGRAM instructions )
			{
			match(input,PROGRAM,FOLLOW_PROGRAM_in_program96); 
			 symtab.openScope(); 
			if ( input.LA(1)==Token.DOWN ) {
				match(input, Token.DOWN, null); 
				pushFollow(FOLLOW_instructions_in_program126);
				instructions();
				state._fsp--;

				 symtab.closeScope(); 
				match(input, Token.UP, null); 
			}

			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "program"



	// $ANTLR start "instructions"
	// StilChecker.g:37:1: instructions : ( declaration | statement | expression )* ;
	public final void instructions() throws RecognitionException {
		try {
			// StilChecker.g:38:5: ( ( declaration | statement | expression )* )
			// StilChecker.g:38:9: ( declaration | statement | expression )*
			{
			// StilChecker.g:38:9: ( declaration | statement | expression )*
			loop1:
			while (true) {
				int alt1=4;
				switch ( input.LA(1) ) {
				case CONST:
				case VAR:
					{
					alt1=1;
					}
					break;
				case IF:
				case WHILE:
					{
					alt1=2;
					}
					break;
				case AND:
				case BECOMES:
				case CHAR_LITERAL:
				case COMPOUND_EXPR:
				case DIVIDE:
				case EQ:
				case FALSE:
				case GT:
				case GTE:
				case IDENTIFIER:
				case INT_LITERAL:
				case LT:
				case LTE:
				case MINUS:
				case MODULO:
				case MULTIPLY:
				case NEQ:
				case OR:
				case PLUS:
				case PRINT:
				case READ:
				case TRUE:
				case UNARY_MINUS:
				case UNARY_NOT:
				case UNARY_PLUS:
					{
					alt1=3;
					}
					break;
				}
				switch (alt1) {
				case 1 :
					// StilChecker.g:38:10: declaration
					{
					pushFollow(FOLLOW_declaration_in_instructions161);
					declaration();
					state._fsp--;

					}
					break;
				case 2 :
					// StilChecker.g:38:24: statement
					{
					pushFollow(FOLLOW_statement_in_instructions165);
					statement();
					state._fsp--;

					}
					break;
				case 3 :
					// StilChecker.g:38:36: expression
					{
					pushFollow(FOLLOW_expression_in_instructions169);
					expression();
					state._fsp--;

					}
					break;

				default :
					break loop1;
				}
			}

			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "instructions"



	// $ANTLR start "declaration"
	// StilChecker.g:41:1: declaration : ( constant_declaration | var_declaration );
	public final void declaration() throws RecognitionException {
		try {
			// StilChecker.g:42:5: ( constant_declaration | var_declaration )
			int alt2=2;
			int LA2_0 = input.LA(1);
			if ( (LA2_0==CONST) ) {
				alt2=1;
			}
			else if ( (LA2_0==VAR) ) {
				alt2=2;
			}

			else {
				NoViableAltException nvae =
					new NoViableAltException("", 2, 0, input);
				throw nvae;
			}

			switch (alt2) {
				case 1 :
					// StilChecker.g:42:9: constant_declaration
					{
					pushFollow(FOLLOW_constant_declaration_in_declaration194);
					constant_declaration();
					state._fsp--;

					}
					break;
				case 2 :
					// StilChecker.g:42:32: var_declaration
					{
					pushFollow(FOLLOW_var_declaration_in_declaration198);
					var_declaration();
					state._fsp--;

					}
					break;

			}
		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "declaration"



	// $ANTLR start "constant_declaration"
	// StilChecker.g:45:1: constant_declaration : ^( CONST t= type id= IDENTIFIER expr= expression ) ;
	public final void constant_declaration() throws RecognitionException {
		StilNode id=null;
		StilNode CONST1=null;
		EntityType t =null;
		EntityType expr =null;

		try {
			// StilChecker.g:46:5: ( ^( CONST t= type id= IDENTIFIER expr= expression ) )
			// StilChecker.g:46:9: ^( CONST t= type id= IDENTIFIER expr= expression )
			{
			CONST1=(StilNode)match(input,CONST,FOLLOW_CONST_in_constant_declaration218); 
			match(input, Token.DOWN, null); 
			pushFollow(FOLLOW_type_in_constant_declaration222);
			t=type();
			state._fsp--;

			id=(StilNode)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_constant_declaration226); 
			pushFollow(FOLLOW_expression_in_constant_declaration230);
			expr=expression();
			state._fsp--;

			match(input, Token.UP, null); 

			 
			            declarationChecker.processConstantDeclaration((DeclNode)CONST1, id, t, symtab); 
			            typeChecker.processConstantAssignmentExpression((DeclNode)CONST1, id, expr, symtab);
			        
			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "constant_declaration"



	// $ANTLR start "var_declaration"
	// StilChecker.g:52:1: var_declaration : ^( VAR t= type id= IDENTIFIER ) ;
	public final void var_declaration() throws RecognitionException {
		StilNode id=null;
		StilNode VAR2=null;
		EntityType t =null;

		try {
			// StilChecker.g:53:5: ( ^( VAR t= type id= IDENTIFIER ) )
			// StilChecker.g:53:9: ^( VAR t= type id= IDENTIFIER )
			{
			VAR2=(StilNode)match(input,VAR,FOLLOW_VAR_in_var_declaration253); 
			match(input, Token.DOWN, null); 
			pushFollow(FOLLOW_type_in_var_declaration257);
			t=type();
			state._fsp--;

			id=(StilNode)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_var_declaration261); 
			match(input, Token.UP, null); 

			 
			            declarationChecker.processVariableDeclaration((DeclNode)VAR2, id, t, symtab);
			        
			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "var_declaration"



	// $ANTLR start "statement"
	// StilChecker.g:58:1: statement : ( if_statement | while_statement ) ;
	public final void statement() throws RecognitionException {
		try {
			// StilChecker.g:59:5: ( ( if_statement | while_statement ) )
			// StilChecker.g:59:9: ( if_statement | while_statement )
			{
			// StilChecker.g:59:9: ( if_statement | while_statement )
			int alt3=2;
			int LA3_0 = input.LA(1);
			if ( (LA3_0==IF) ) {
				alt3=1;
			}
			else if ( (LA3_0==WHILE) ) {
				alt3=2;
			}

			else {
				NoViableAltException nvae =
					new NoViableAltException("", 3, 0, input);
				throw nvae;
			}

			switch (alt3) {
				case 1 :
					// StilChecker.g:59:10: if_statement
					{
					pushFollow(FOLLOW_if_statement_in_statement284);
					if_statement();
					state._fsp--;

					}
					break;
				case 2 :
					// StilChecker.g:59:25: while_statement
					{
					pushFollow(FOLLOW_while_statement_in_statement288);
					while_statement();
					state._fsp--;

					}
					break;

			}

			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "statement"



	// $ANTLR start "if_statement"
	// StilChecker.g:62:1: if_statement : ^( IF expr= expression instructions ( ELSE instructions )? ) ;
	public final void if_statement() throws RecognitionException {
		StilNode IF3=null;
		EntityType expr =null;

		try {
			// StilChecker.g:63:5: ( ^( IF expr= expression instructions ( ELSE instructions )? ) )
			// StilChecker.g:63:9: ^( IF expr= expression instructions ( ELSE instructions )? )
			{
			IF3=(StilNode)match(input,IF,FOLLOW_IF_in_if_statement311); 
			 symtab.openScope();                                  
			match(input, Token.DOWN, null); 
			pushFollow(FOLLOW_expression_in_if_statement342);
			expr=expression();
			state._fsp--;

			 typeChecker.processIfStatement((StilNode)IF3, expr); 
			pushFollow(FOLLOW_instructions_in_if_statement358);
			instructions();
			state._fsp--;

			 symtab.closeScope();                                 
			// StilChecker.g:66:10: ( ELSE instructions )?
			int alt4=2;
			int LA4_0 = input.LA(1);
			if ( (LA4_0==ELSE) ) {
				alt4=1;
			}
			switch (alt4) {
				case 1 :
					// StilChecker.g:66:13: ELSE instructions
					{
					match(input,ELSE,FOLLOW_ELSE_in_if_statement377); 
					 symtab.openScope();                                  
					pushFollow(FOLLOW_instructions_in_if_statement404);
					instructions();
					state._fsp--;

					 symtab.closeScope();                                 
					}
					break;

			}

			match(input, Token.UP, null); 

			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "if_statement"



	// $ANTLR start "while_statement"
	// StilChecker.g:70:1: while_statement : ^( WHILE expr= expression instructions ) ;
	public final void while_statement() throws RecognitionException {
		StilNode WHILE4=null;
		EntityType expr =null;

		try {
			// StilChecker.g:71:5: ( ^( WHILE expr= expression instructions ) )
			// StilChecker.g:71:9: ^( WHILE expr= expression instructions )
			{
			WHILE4=(StilNode)match(input,WHILE,FOLLOW_WHILE_in_while_statement434); 
			 symtab.openScope();                                        
			match(input, Token.DOWN, null); 
			pushFollow(FOLLOW_expression_in_while_statement462);
			expr=expression();
			state._fsp--;

			 typeChecker.processWhileStatement((StilNode)WHILE4, expr); 
			pushFollow(FOLLOW_instructions_in_while_statement478);
			instructions();
			state._fsp--;

			 symtab.closeScope();                                       
			match(input, Token.UP, null); 

			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "while_statement"



	// $ANTLR start "print_statement"
	// StilChecker.g:76:1: print_statement returns [EntityType entityType = null;] : ^(node= PRINT t= expression (t= expression )* ) ;
	public final EntityType print_statement() throws RecognitionException {
		EntityType entityType =  null;;


		StilNode node=null;
		EntityType t =null;

		try {
			// StilChecker.g:77:5: ( ^(node= PRINT t= expression (t= expression )* ) )
			// StilChecker.g:77:9: ^(node= PRINT t= expression (t= expression )* )
			{
			node=(StilNode)match(input,PRINT,FOLLOW_PRINT_in_print_statement513); 
			match(input, Token.DOWN, null); 
			pushFollow(FOLLOW_expression_in_print_statement530);
			t=expression();
			state._fsp--;

			 entityType = typeChecker.processPrintStatement((ExprNode)node, t); 
			// StilChecker.g:79:10: (t= expression )*
			loop5:
			while (true) {
				int alt5=2;
				int LA5_0 = input.LA(1);
				if ( (LA5_0==AND||LA5_0==BECOMES||LA5_0==CHAR_LITERAL||LA5_0==COMPOUND_EXPR||LA5_0==DIVIDE||(LA5_0 >= EQ && LA5_0 <= IDENTIFIER)||LA5_0==INT_LITERAL||(LA5_0 >= LT && LA5_0 <= NEQ)||(LA5_0 >= OR && LA5_0 <= PRINT)||LA5_0==READ||(LA5_0 >= TRUE && LA5_0 <= UNARY_PLUS)) ) {
					alt5=1;
				}

				switch (alt5) {
				case 1 :
					// StilChecker.g:79:13: t= expression
					{
					pushFollow(FOLLOW_expression_in_print_statement549);
					t=expression();
					state._fsp--;

					 entityType = typeChecker.processMultiplePrintStatement((ExprNode)node, t); 
					}
					break;

				default :
					break loop5;
				}
			}

			match(input, Token.UP, null); 

			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return entityType;
	}
	// $ANTLR end "print_statement"



	// $ANTLR start "read_statement"
	// StilChecker.g:83:1: read_statement returns [EntityType entityType = null;] : ^(node= READ id= IDENTIFIER (id= IDENTIFIER )* ) ;
	public final EntityType read_statement() throws RecognitionException {
		EntityType entityType =  null;;


		StilNode node=null;
		StilNode id=null;

		try {
			// StilChecker.g:84:5: ( ^(node= READ id= IDENTIFIER (id= IDENTIFIER )* ) )
			// StilChecker.g:84:9: ^(node= READ id= IDENTIFIER (id= IDENTIFIER )* )
			{
			node=(StilNode)match(input,READ,FOLLOW_READ_in_read_statement584); 
			match(input, Token.DOWN, null); 
			id=(StilNode)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_read_statement601); 
			 entityType = declarationChecker.retrieveDeclaration((ExprNode)node, id, symtab, true); 
			// StilChecker.g:86:9: (id= IDENTIFIER )*
			loop6:
			while (true) {
				int alt6=2;
				int LA6_0 = input.LA(1);
				if ( (LA6_0==IDENTIFIER) ) {
					alt6=1;
				}

				switch (alt6) {
				case 1 :
					// StilChecker.g:86:13: id= IDENTIFIER
					{
					id=(StilNode)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_read_statement620); 
					 entityType = declarationChecker.retrieveMultipleDeclaration((ExprNode)node, id, symtab, true); 
					}
					break;

				default :
					break loop6;
				}
			}

			match(input, Token.UP, null); 

			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return entityType;
	}
	// $ANTLR end "read_statement"



	// $ANTLR start "compound_expression"
	// StilChecker.g:89:1: compound_expression returns [EntityType entityType = null;] : ( ( declaration | statement )* expr= expression )* ;
	public final EntityType compound_expression() throws RecognitionException {
		EntityType entityType =  null;;


		EntityType expr =null;

		try {
			// StilChecker.g:90:5: ( ( ( declaration | statement )* expr= expression )* )
			// StilChecker.g:90:9: ( ( declaration | statement )* expr= expression )*
			{
			// StilChecker.g:90:9: ( ( declaration | statement )* expr= expression )*
			loop8:
			while (true) {
				int alt8=2;
				int LA8_0 = input.LA(1);
				if ( (LA8_0==AND||LA8_0==BECOMES||LA8_0==CHAR_LITERAL||(LA8_0 >= COMPOUND_EXPR && LA8_0 <= CONST)||LA8_0==DIVIDE||(LA8_0 >= EQ && LA8_0 <= IF)||LA8_0==INT_LITERAL||(LA8_0 >= LT && LA8_0 <= NEQ)||(LA8_0 >= OR && LA8_0 <= PRINT)||LA8_0==READ||(LA8_0 >= TRUE && LA8_0 <= UNARY_PLUS)||(LA8_0 >= VAR && LA8_0 <= WHILE)) ) {
					alt8=1;
				}

				switch (alt8) {
				case 1 :
					// StilChecker.g:90:10: ( declaration | statement )* expr= expression
					{
					// StilChecker.g:90:10: ( declaration | statement )*
					loop7:
					while (true) {
						int alt7=3;
						int LA7_0 = input.LA(1);
						if ( (LA7_0==CONST||LA7_0==VAR) ) {
							alt7=1;
						}
						else if ( (LA7_0==IF||LA7_0==WHILE) ) {
							alt7=2;
						}

						switch (alt7) {
						case 1 :
							// StilChecker.g:90:11: declaration
							{
							pushFollow(FOLLOW_declaration_in_compound_expression650);
							declaration();
							state._fsp--;

							}
							break;
						case 2 :
							// StilChecker.g:90:25: statement
							{
							pushFollow(FOLLOW_statement_in_compound_expression654);
							statement();
							state._fsp--;

							}
							break;

						default :
							break loop7;
						}
					}

					pushFollow(FOLLOW_expression_in_compound_expression660);
					expr=expression();
					state._fsp--;

					 entityType = expr; 
					}
					break;

				default :
					break loop8;
				}
			}

			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return entityType;
	}
	// $ANTLR end "compound_expression"



	// $ANTLR start "closed_compound_expression"
	// StilChecker.g:95:1: closed_compound_expression returns [EntityType entityType = null;] : ^(node= COMPOUND_EXPR c= compound_expression ) ;
	public final EntityType closed_compound_expression() throws RecognitionException {
		EntityType entityType =  null;;


		StilNode node=null;
		EntityType c =null;

		try {
			// StilChecker.g:96:5: ( ^(node= COMPOUND_EXPR c= compound_expression ) )
			// StilChecker.g:96:9: ^(node= COMPOUND_EXPR c= compound_expression )
			{
			node=(StilNode)match(input,COMPOUND_EXPR,FOLLOW_COMPOUND_EXPR_in_closed_compound_expression694); 
			   symtab.openScope();     
			if ( input.LA(1)==Token.DOWN ) {
				match(input, Token.DOWN, null); 
				pushFollow(FOLLOW_compound_expression_in_closed_compound_expression718);
				c=compound_expression();
				state._fsp--;

				   entityType = c; ((ExprNode)node).setEntityType(entityType); 
				                                        symtab.closeScope();    
				match(input, Token.UP, null); 
			}

			}

		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return entityType;
	}
	// $ANTLR end "closed_compound_expression"



	// $ANTLR start "expression"
	// StilChecker.g:101:1: expression returns [EntityType entityType = null;] : (p= print_statement |r= read_statement |o= operand |c= closed_compound_expression | ^(node= BECOMES id= IDENTIFIER t1= expression ) | ^(node= OR t1= expression t2= expression ) | ^(node= AND t1= expression t2= expression ) | ^(node= LT t1= expression t2= expression ) | ^(node= LTE t1= expression t2= expression ) | ^(node= GT t1= expression t2= expression ) | ^(node= GTE t1= expression t2= expression ) | ^(node= EQ t1= expression t2= expression ) | ^(node= NEQ t1= expression t2= expression ) | ^(node= PLUS t1= expression t2= expression ) | ^(node= MINUS t1= expression t2= expression ) | ^(node= DIVIDE t1= expression t2= expression ) | ^(node= MULTIPLY t1= expression t2= expression ) | ^(node= MODULO t1= expression t2= expression ) | ^(node= UNARY_PLUS t1= expression ) | ^(node= UNARY_MINUS t1= expression ) | ^(node= UNARY_NOT t1= expression ) );
	public final EntityType expression() throws RecognitionException {
		EntityType entityType =  null;;


		StilNode node=null;
		StilNode id=null;
		EntityType p =null;
		EntityType r =null;
		EntityType o =null;
		EntityType c =null;
		EntityType t1 =null;
		EntityType t2 =null;

		try {
			// StilChecker.g:102:5: (p= print_statement |r= read_statement |o= operand |c= closed_compound_expression | ^(node= BECOMES id= IDENTIFIER t1= expression ) | ^(node= OR t1= expression t2= expression ) | ^(node= AND t1= expression t2= expression ) | ^(node= LT t1= expression t2= expression ) | ^(node= LTE t1= expression t2= expression ) | ^(node= GT t1= expression t2= expression ) | ^(node= GTE t1= expression t2= expression ) | ^(node= EQ t1= expression t2= expression ) | ^(node= NEQ t1= expression t2= expression ) | ^(node= PLUS t1= expression t2= expression ) | ^(node= MINUS t1= expression t2= expression ) | ^(node= DIVIDE t1= expression t2= expression ) | ^(node= MULTIPLY t1= expression t2= expression ) | ^(node= MODULO t1= expression t2= expression ) | ^(node= UNARY_PLUS t1= expression ) | ^(node= UNARY_MINUS t1= expression ) | ^(node= UNARY_NOT t1= expression ) )
			int alt9=21;
			switch ( input.LA(1) ) {
			case PRINT:
				{
				alt9=1;
				}
				break;
			case READ:
				{
				alt9=2;
				}
				break;
			case CHAR_LITERAL:
			case FALSE:
			case IDENTIFIER:
			case INT_LITERAL:
			case TRUE:
				{
				alt9=3;
				}
				break;
			case COMPOUND_EXPR:
				{
				alt9=4;
				}
				break;
			case BECOMES:
				{
				alt9=5;
				}
				break;
			case OR:
				{
				alt9=6;
				}
				break;
			case AND:
				{
				alt9=7;
				}
				break;
			case LT:
				{
				alt9=8;
				}
				break;
			case LTE:
				{
				alt9=9;
				}
				break;
			case GT:
				{
				alt9=10;
				}
				break;
			case GTE:
				{
				alt9=11;
				}
				break;
			case EQ:
				{
				alt9=12;
				}
				break;
			case NEQ:
				{
				alt9=13;
				}
				break;
			case PLUS:
				{
				alt9=14;
				}
				break;
			case MINUS:
				{
				alt9=15;
				}
				break;
			case DIVIDE:
				{
				alt9=16;
				}
				break;
			case MULTIPLY:
				{
				alt9=17;
				}
				break;
			case MODULO:
				{
				alt9=18;
				}
				break;
			case UNARY_PLUS:
				{
				alt9=19;
				}
				break;
			case UNARY_MINUS:
				{
				alt9=20;
				}
				break;
			case UNARY_NOT:
				{
				alt9=21;
				}
				break;
			default:
				NoViableAltException nvae =
					new NoViableAltException("", 9, 0, input);
				throw nvae;
			}
			switch (alt9) {
				case 1 :
					// StilChecker.g:102:9: p= print_statement
					{
					pushFollow(FOLLOW_print_statement_in_expression749);
					p=print_statement();
					state._fsp--;

					 entityType = p;
					}
					break;
				case 2 :
					// StilChecker.g:103:9: r= read_statement
					{
					pushFollow(FOLLOW_read_statement_in_expression777);
					r=read_statement();
					state._fsp--;

					 entityType = r;
					}
					break;
				case 3 :
					// StilChecker.g:104:9: o= operand
					{
					pushFollow(FOLLOW_operand_in_expression806);
					o=operand();
					state._fsp--;

					 entityType = o; 
					}
					break;
				case 4 :
					// StilChecker.g:105:9: c= closed_compound_expression
					{
					pushFollow(FOLLOW_closed_compound_expression_in_expression842);
					c=closed_compound_expression();
					state._fsp--;

					 entityType = c; 
					}
					break;
				case 5 :
					// StilChecker.g:106:9: ^(node= BECOMES id= IDENTIFIER t1= expression )
					{
					node=(StilNode)match(input,BECOMES,FOLLOW_BECOMES_in_expression860); 
					match(input, Token.DOWN, null); 
					id=(StilNode)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_expression864); 
					pushFollow(FOLLOW_expression_in_expression868);
					t1=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processVariableAssignmentExpression((ExprNode)node, id, t1, symtab); 
					}
					break;
				case 6 :
					// StilChecker.g:107:9: ^(node= OR t1= expression t2= expression )
					{
					node=(StilNode)match(input,OR,FOLLOW_OR_in_expression888); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression892);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression896);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.OR, t1, t2); 
					}
					break;
				case 7 :
					// StilChecker.g:108:9: ^(node= AND t1= expression t2= expression )
					{
					node=(StilNode)match(input,AND,FOLLOW_AND_in_expression918); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression922);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression926);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.AND, t1, t2); 
					}
					break;
				case 8 :
					// StilChecker.g:109:9: ^(node= LT t1= expression t2= expression )
					{
					node=(StilNode)match(input,LT,FOLLOW_LT_in_expression947); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression951);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression955);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.LT, t1, t2); 
					}
					break;
				case 9 :
					// StilChecker.g:110:9: ^(node= LTE t1= expression t2= expression )
					{
					node=(StilNode)match(input,LTE,FOLLOW_LTE_in_expression977); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression981);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression985);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.LTE, t1, t2); 
					}
					break;
				case 10 :
					// StilChecker.g:111:9: ^(node= GT t1= expression t2= expression )
					{
					node=(StilNode)match(input,GT,FOLLOW_GT_in_expression1006); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1010);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1014);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.GT, t1, t2); 
					}
					break;
				case 11 :
					// StilChecker.g:112:9: ^(node= GTE t1= expression t2= expression )
					{
					node=(StilNode)match(input,GTE,FOLLOW_GTE_in_expression1036); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1040);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1044);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.GTE, t1, t2); 
					}
					break;
				case 12 :
					// StilChecker.g:113:9: ^(node= EQ t1= expression t2= expression )
					{
					node=(StilNode)match(input,EQ,FOLLOW_EQ_in_expression1065); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1069);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1073);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.EQ, t1, t2); 
					}
					break;
				case 13 :
					// StilChecker.g:114:9: ^(node= NEQ t1= expression t2= expression )
					{
					node=(StilNode)match(input,NEQ,FOLLOW_NEQ_in_expression1095); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1099);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1103);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.NEQ, t1, t2); 
					}
					break;
				case 14 :
					// StilChecker.g:115:9: ^(node= PLUS t1= expression t2= expression )
					{
					node=(StilNode)match(input,PLUS,FOLLOW_PLUS_in_expression1124); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1128);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1132);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.PLUS, t1, t2); 
					}
					break;
				case 15 :
					// StilChecker.g:116:9: ^(node= MINUS t1= expression t2= expression )
					{
					node=(StilNode)match(input,MINUS,FOLLOW_MINUS_in_expression1152); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1156);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1160);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.MINUS, t1, t2); 
					}
					break;
				case 16 :
					// StilChecker.g:117:9: ^(node= DIVIDE t1= expression t2= expression )
					{
					node=(StilNode)match(input,DIVIDE,FOLLOW_DIVIDE_in_expression1179); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1183);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1187);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.DIVIDE, t1, t2); 
					}
					break;
				case 17 :
					// StilChecker.g:118:9: ^(node= MULTIPLY t1= expression t2= expression )
					{
					node=(StilNode)match(input,MULTIPLY,FOLLOW_MULTIPLY_in_expression1205); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1209);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1213);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.MULTIPLY, t1, t2); 
					}
					break;
				case 18 :
					// StilChecker.g:119:9: ^(node= MODULO t1= expression t2= expression )
					{
					node=(StilNode)match(input,MODULO,FOLLOW_MODULO_in_expression1229); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1233);
					t1=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression1237);
					t2=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.MODULO, t1, t2); 
					}
					break;
				case 19 :
					// StilChecker.g:120:9: ^(node= UNARY_PLUS t1= expression )
					{
					node=(StilNode)match(input,UNARY_PLUS,FOLLOW_UNARY_PLUS_in_expression1255); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1259);
					t1=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.UNARY_PLUS, t1); 
					}
					break;
				case 20 :
					// StilChecker.g:121:9: ^(node= UNARY_MINUS t1= expression )
					{
					node=(StilNode)match(input,UNARY_MINUS,FOLLOW_UNARY_MINUS_in_expression1287); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1291);
					t1=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.UNARY_MINUS, t1); 
					}
					break;
				case 21 :
					// StilChecker.g:122:9: ^(node= UNARY_NOT t1= expression )
					{
					node=(StilNode)match(input,UNARY_NOT,FOLLOW_UNARY_NOT_in_expression1318); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression1322);
					t1=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					 entityType = typeChecker.processLogicExpression((LogicExprNode)node, Operator.NOT, t1); 
					}
					break;

			}
		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return entityType;
	}
	// $ANTLR end "expression"



	// $ANTLR start "operand"
	// StilChecker.g:126:1: operand returns [EntityType entityType = null;] : (id= IDENTIFIER |node= ( TRUE | FALSE ) |node= CHAR_LITERAL |node= INT_LITERAL );
	public final EntityType operand() throws RecognitionException {
		EntityType entityType =  null;;


		StilNode id=null;
		StilNode node=null;

		try {
			// StilChecker.g:127:5: (id= IDENTIFIER |node= ( TRUE | FALSE ) |node= CHAR_LITERAL |node= INT_LITERAL )
			int alt10=4;
			switch ( input.LA(1) ) {
			case IDENTIFIER:
				{
				alt10=1;
				}
				break;
			case FALSE:
			case TRUE:
				{
				alt10=2;
				}
				break;
			case CHAR_LITERAL:
				{
				alt10=3;
				}
				break;
			case INT_LITERAL:
				{
				alt10=4;
				}
				break;
			default:
				NoViableAltException nvae =
					new NoViableAltException("", 10, 0, input);
				throw nvae;
			}
			switch (alt10) {
				case 1 :
					// StilChecker.g:127:9: id= IDENTIFIER
					{
					id=(StilNode)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_operand1369); 
					 entityType = declarationChecker.retrieveDeclaration(id, id, symtab, false); ((IdNode)id).setEntityType(entityType);
					}
					break;
				case 2 :
					// StilChecker.g:128:9: node= ( TRUE | FALSE )
					{
					node=(StilNode)input.LT(1);
					if ( input.LA(1)==FALSE||input.LA(1)==TRUE ) {
						input.consume();
						state.errorRecovery=false;
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						throw mse;
					}
					 entityType = EntityType.BOOL; ((LiteralNode)node).setEntityType(entityType); 
					}
					break;
				case 3 :
					// StilChecker.g:129:9: node= CHAR_LITERAL
					{
					node=(StilNode)match(input,CHAR_LITERAL,FOLLOW_CHAR_LITERAL_in_operand1406); 
					 entityType = EntityType.CHAR; ((LiteralNode)node).setEntityType(entityType); 
					}
					break;
				case 4 :
					// StilChecker.g:130:9: node= INT_LITERAL
					{
					node=(StilNode)match(input,INT_LITERAL,FOLLOW_INT_LITERAL_in_operand1423); 
					 entityType = EntityType.INT; ((LiteralNode)node).setEntityType(entityType); 
					}
					break;

			}
		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return entityType;
	}
	// $ANTLR end "operand"



	// $ANTLR start "type"
	// StilChecker.g:133:1: type returns [EntityType entityType = null;] : ( BOOL | CHAR | INT );
	public final EntityType type() throws RecognitionException {
		EntityType entityType =  null;;


		try {
			// StilChecker.g:134:5: ( BOOL | CHAR | INT )
			int alt11=3;
			switch ( input.LA(1) ) {
			case BOOL:
				{
				alt11=1;
				}
				break;
			case CHAR:
				{
				alt11=2;
				}
				break;
			case INT:
				{
				alt11=3;
				}
				break;
			default:
				NoViableAltException nvae =
					new NoViableAltException("", 11, 0, input);
				throw nvae;
			}
			switch (alt11) {
				case 1 :
					// StilChecker.g:134:9: BOOL
					{
					match(input,BOOL,FOLLOW_BOOL_in_type1456); 
					 entityType = EntityType.BOOL; 
					}
					break;
				case 2 :
					// StilChecker.g:135:9: CHAR
					{
					match(input,CHAR,FOLLOW_CHAR_in_type1471); 
					 entityType = EntityType.CHAR; 
					}
					break;
				case 3 :
					// StilChecker.g:136:9: INT
					{
					match(input,INT,FOLLOW_INT_in_type1486); 
					 entityType = EntityType.INT; 
					}
					break;

			}
		}
		 
		    catch (RecognitionException e) { 
		        throw e; 
		    } 

		finally {
			// do for sure before leaving
		}
		return entityType;
	}
	// $ANTLR end "type"

	// Delegated rules



	public static final BitSet FOLLOW_PROGRAM_in_program96 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_instructions_in_program126 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_declaration_in_instructions161 = new BitSet(new long[]{0x001BC9DF85FAC452L});
	public static final BitSet FOLLOW_statement_in_instructions165 = new BitSet(new long[]{0x001BC9DF85FAC452L});
	public static final BitSet FOLLOW_expression_in_instructions169 = new BitSet(new long[]{0x001BC9DF85FAC452L});
	public static final BitSet FOLLOW_constant_declaration_in_declaration194 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_var_declaration_in_declaration198 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_CONST_in_constant_declaration218 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_type_in_constant_declaration222 = new BitSet(new long[]{0x0000000000800000L});
	public static final BitSet FOLLOW_IDENTIFIER_in_constant_declaration226 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_constant_declaration230 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_VAR_in_var_declaration253 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_type_in_var_declaration257 = new BitSet(new long[]{0x0000000000800000L});
	public static final BitSet FOLLOW_IDENTIFIER_in_var_declaration261 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_if_statement_in_statement284 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_while_statement_in_statement288 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IF_in_if_statement311 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_if_statement342 = new BitSet(new long[]{0x001BC9DF85FEC458L});
	public static final BitSet FOLLOW_instructions_in_if_statement358 = new BitSet(new long[]{0x0000000000040008L});
	public static final BitSet FOLLOW_ELSE_in_if_statement377 = new BitSet(new long[]{0x001BC9DF85FAC458L});
	public static final BitSet FOLLOW_instructions_in_if_statement404 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_WHILE_in_while_statement434 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_while_statement462 = new BitSet(new long[]{0x001BC9DF85FAC458L});
	public static final BitSet FOLLOW_instructions_in_while_statement478 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_PRINT_in_print_statement513 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_print_statement530 = new BitSet(new long[]{0x0003C9DF84FA4458L});
	public static final BitSet FOLLOW_expression_in_print_statement549 = new BitSet(new long[]{0x0003C9DF84FA4458L});
	public static final BitSet FOLLOW_READ_in_read_statement584 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_IDENTIFIER_in_read_statement601 = new BitSet(new long[]{0x0000000000800008L});
	public static final BitSet FOLLOW_IDENTIFIER_in_read_statement620 = new BitSet(new long[]{0x0000000000800008L});
	public static final BitSet FOLLOW_declaration_in_compound_expression650 = new BitSet(new long[]{0x001BC9DF85FAC450L});
	public static final BitSet FOLLOW_statement_in_compound_expression654 = new BitSet(new long[]{0x001BC9DF85FAC450L});
	public static final BitSet FOLLOW_expression_in_compound_expression660 = new BitSet(new long[]{0x001BC9DF85FAC452L});
	public static final BitSet FOLLOW_COMPOUND_EXPR_in_closed_compound_expression694 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_compound_expression_in_closed_compound_expression718 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_print_statement_in_expression749 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_read_statement_in_expression777 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_operand_in_expression806 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_closed_compound_expression_in_expression842 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_BECOMES_in_expression860 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_IDENTIFIER_in_expression864 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression868 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_OR_in_expression888 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression892 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression896 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_AND_in_expression918 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression922 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression926 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_LT_in_expression947 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression951 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression955 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_LTE_in_expression977 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression981 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression985 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_GT_in_expression1006 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1010 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1014 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_GTE_in_expression1036 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1040 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1044 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_EQ_in_expression1065 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1069 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1073 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_NEQ_in_expression1095 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1099 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1103 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_PLUS_in_expression1124 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1128 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1132 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_MINUS_in_expression1152 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1156 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1160 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_DIVIDE_in_expression1179 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1183 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1187 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_MULTIPLY_in_expression1205 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1209 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1213 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_MODULO_in_expression1229 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1233 = new BitSet(new long[]{0x0003C9DF84FA4450L});
	public static final BitSet FOLLOW_expression_in_expression1237 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_UNARY_PLUS_in_expression1255 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1259 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_UNARY_MINUS_in_expression1287 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1291 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_UNARY_NOT_in_expression1318 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression1322 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_IDENTIFIER_in_operand1369 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_set_in_operand1385 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_CHAR_LITERAL_in_operand1406 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_INT_LITERAL_in_operand1423 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_BOOL_in_type1456 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_CHAR_in_type1471 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_INT_in_type1486 = new BitSet(new long[]{0x0000000000000002L});
}
